"""Create harmless demo files for the five practical-demo tasks:  python scripts/seed_demo_files.py"""
from pathlib import Path

from openpyxl import Workbook

home = Path.home()
(home / "Downloads").mkdir(exist_ok=True)
(home / "Documents" / "AgentTests").mkdir(parents=True, exist_ok=True)

report = home / "Downloads" / "report_draft.txt"
if not report.exists():
    report.write_text("Demo report used to test rename + move.\n")

xlsx = home / "Documents" / "AgentTests" / "contacts.xlsx"
if not xlsx.exists():
    wb = Workbook()
    wb.active.title = "Contacts"
    wb.active.append(["Name", "Email", "City"])
    wb.save(xlsx)

print("Seeded:", report, xlsx)
