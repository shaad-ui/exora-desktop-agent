# Exora AI Desktop Automation Agent (Google ADK)

An autonomous agent that operates a real computer from plain-English instructions: it plans, acts through
tools (screen, mouse, keyboard, Playwright browser, file system, `.xlsx`), observes the result, recovers from
failures, **verifies** the outcome before claiming success, and **pauses for human approval** before submitting forms.

## Project structure

```
exora-desktop-agent/
├── main.py                    # headless CLI runner (terminal approval prompt)
├── ui.py                      # Streamlit UI (start/stop, live log, plan, approval, status)
├── requirements.txt  .env.example  .gitignore
├── exora_agent/
│   ├── agent.py               # ADK Agent (root_agent): instruction + tools + callbacks
│   ├── prompts.py             # system instruction (planning, safety, recovery, verification)
│   ├── callbacks.py           # before_model / before_tool / after_tool: tracking, loop guard, verification state
│   ├── runtime.py             # ADK Runner + SessionService, background thread, Stop, final status
│   ├── tracking.py            # ExecutionTracker, STOP flag, ApprovalGate (thread-safe)
│   ├── config.py              # env-driven settings (model, sandbox roots, browser)
│   └── tools/
│       ├── computer.py        # observe_screen, click, type_text, hotkey, scroll, open_application, windows
│       ├── browser.py         # Playwright: navigate, DOM state, click/fill, extract, download, popups, approval guard
│       ├── files.py           # search / rename / move / exists / wait_for_file / read / write (sandboxed, no delete)
│       ├── spreadsheet.py     # openpyxl create / read / write cell / write row / verify cell
│       ├── control.py         # set_plan, update_plan_step, request_user_approval, declare_task_complete
│       ├── common.py          # result envelope, safe_tool, retry, path sandbox
│       └── vision.py          # screenshot hand-off to the model
├── tests/                     # offline tests + end-to-end ADK test with a scripted model
├── scripts/seed_demo_files.py # creates demo files for the practical tasks
└── docs/PROMPT_LOG.md  docs/TEST_REPORT.md   # submission templates - fill with YOUR real runs
```

## How it works (what to explain in the interview)

1. **ADK agent** - `agent.py` defines one `LlmAgent` (`root_agent`) with an explicit instruction, 50 plain-Python
   function tools (ADK wraps each as a `FunctionTool` from type hints + docstrings) and three callbacks.
2. **Plan -> act -> observe -> verify -> decide** - the instruction enforces the loop; `set_plan` /
   `update_plan_step` make the plan visible in the UI and stored in ADK session state.
3. **Computer interaction** - `observe_screen` captures the screen (downscaled, with a labelled 100 px grid).
   A tool can only return JSON, so the PNG is parked in `vision.py` and `before_model_callback` attaches it to the
   next model request (only for vision-capable models; Llama 3.3 70B is text-only, so it runs in "text-only mode" using DOM/file/keyboard tools). `click(x, y)` coordinates are mapped back to real screen
   pixels (HiDPI-safe). For web pages the agent uses DOM observation instead: `browser_get_page_state` tags every
   visible control with a number, so actions are `browser_click("12")`, not pixel guessing.
4. **Error handling & recovery** - every tool is wrapped by `safe_tool`: exceptions become `{"status":"error",
   "hint": ...}` instead of crashing. Built-in fallbacks: click = normal -> scroll+force -> JS click; navigation retries
   with backoff and tolerates slow loads; JS dialogs and new tabs are handled; a crashed browser relaunches;
   `browser_dismiss_popups`; `wait_for_file`; download via click *or* direct URL. The loop breaker blocks a call repeated
   3x with identical arguments, and 4 consecutive failures inject an "escalation" message forcing a re-plan.
5. **Strict verification** - `after_tool_callback` keeps `unverified_actions` and `verifications` in session state.
   Actions add to the unverified list; observation/verifier tools (`file_exists`, `browser_verify`,
   `spreadsheet_verify_cell`, `observe_screen`, ...) clear it; mutating tools also re-check themselves
   (`verified: true/false`). `declare_task_complete(success=True)` is **rejected in code** unless evidence is given,
   at least one verification happened, and nothing is left unverified. If the run ends without an accepted
   declaration the UI shows FAILED, never SUCCESS.
6. **Approval before submission** - `request_user_approval` is an async tool that blocks until the user clicks
   Approve/Reject in the UI. It produces a single-use grant; `browser_click` refuses submit-like controls (and
   Enter inside form fields) without it. Safety is enforced by code, not only by the prompt.
7. **Sessions & tracking** - one ADK session per task (`InMemorySessionService`, or SQLite via `EXORA_SESSION_DB`),
   optional follow-up in the same session. `ExecutionTracker` records status, plan, every tool call/result,
   counters and the final evidence; the UI polls it once per second.
8. **Stop** - sets a global flag (tools abort at their next step) and cancels the asyncio task (aborts a pending model call).
   Moving the mouse into a screen corner triggers PyAutoGUI's fail-safe.

## Setup

Requires **Python 3.10+**, a Groq API key (https://console.groq.com/keys), and a desktop session (not a headless server) for the GUI tools.

```bash
cd exora-desktop-agent
python -m venv .venv
# Windows:  .venv\Scripts\activate        macOS/Linux:  source .venv/bin/activate
pip install -r requirements.txt
playwright install chromium          # or set EXORA_BROWSER_CHANNEL=chrome to use your installed Chrome
cp .env.example .env                 # then put your GROQ_API_KEY (https://console.groq.com/keys) in .env
python scripts/seed_demo_files.py    # optional demo files
```

Permissions (the agent genuinely controls the machine - use a test account/VM if possible):
* **macOS**: System Settings -> Privacy & Security -> grant your terminal/IDE *Accessibility* and *Screen Recording*.
* **Windows**: nothing special; do not run the target apps as Administrator unless the agent is too.
* **Linux**: use an X11 session (Wayland blocks synthetic input); `sudo apt install python3-tk python3-dev scrot wmctrl`.
* `EXORA_ALLOWED_ROOTS` limits where file tools may read/write (default: your home folder). If Documents is
  OneDrive-redirected on Windows, add that path.

## Run

```bash
streamlit run ui.py                       # UI at http://localhost:8501
python main.py "Find report_draft.txt in Downloads, rename it to report_final.txt and move it to Documents/Archive"
python -m pytest -q                       # offline tests (no key/display needed)
adk web                                   # optional: ADK dev UI, run from the folder that CONTAINS exora_agent/
```

## Practical-demo scripts (paste into the UI)

| Demo task | Instruction |
|---|---|
| Download a file | `Open https://the-internet.herokuapp.com/download, download the first .txt file and save it in ~/Documents/AgentTests` |
| Rename + move | `Find report_draft.txt in ~/Downloads, rename it to report_final.txt and move it to ~/Documents/Archive` |
| Spreadsheet | `Open ~/Documents/AgentTests/contacts.xlsx and add a row: Asha Rao, asha@example.com, Bengaluru` |
| Form, stop before submit | `Go to https://www.selenium.dev/selenium/web/web-form.html, fill the text field with "Exora Test", the password field with "demo123" and the textarea with "Hello", then stop for my approval before submitting` |
| Unexpected situation | `Find invoice_march.pdf in ~/Downloads, rename it to invoice_final.pdf and move it to ~/Documents/Archive` (file does not exist -> watch it search, then report honestly) - or ask it to download from a page with a cookie banner / slow load |

## Honest limitations

* Pixel clicking depends on the model's visual accuracy; the grid overlay helps, but the DOM tools are far more
  reliable for web work. Native-app automation is the weakest path - verify it with screenshots in your testing report.
* One task at a time; one automated browser (a fresh Chromium profile - not logged in to your accounts).
* Credentials typed by the agent appear in the execution log; use throw-away test accounts.
* The agent has no delete tool and will not overwrite files, by design.
