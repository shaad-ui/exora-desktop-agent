"""Streamlit UI:  streamlit run ui.py

Left: task input, Start / Stop, session options.  Right: live status, plan, approval checkpoint,
step log and the latest screenshot. The live panel is a fragment that re-renders itself every second
while the agent works in a background thread.
"""
import time
from pathlib import Path

import streamlit as st

from exora_agent.config import ALLOWED_ROOTS, DOWNLOAD_DIR, MODEL
from exora_agent.preflight import check_llm, key_info
from exora_agent.runtime import AgentTaskController
from exora_agent.tracking import APPROVAL, TRACKER

st.set_page_config(page_title="Exora Desktop Agent", page_icon="🖥️", layout="wide")


@st.cache_resource
def get_controller() -> AgentTaskController:
    """One controller (ADK runner + session service) per server process."""
    return AgentTaskController()


ctrl = get_controller()

ICONS = {"system": "⚙️", "plan": "🗺️", "agent": "💬", "tool_call": "🔧", "tool_result": "📥",
         "error": "⚠️", "approval": "✋", "info": "ℹ️"}
STATUS_BADGE = {
    "idle": ("info", "IDLE - enter a task and press Start"),
    "running": ("info", "RUNNING - the agent is working"),
    "awaiting_approval": ("warning", "WAITING FOR YOUR APPROVAL"),
    "stopping": ("warning", "STOPPING..."),
    "success": ("success", "SUCCESS - completed and verified"),
    "failed": ("error", "FAILED - task not completed"),
    "stopped": ("warning", "STOPPED by user"),
}
PLAN_ICON = {"pending": "⬜", "in_progress": "🔄", "done": "✅", "failed": "❌", "skipped": "⏭️"}

# ------------------------------------------------------------------------ sidebar
with st.sidebar:
    st.header("Configuration")
    st.write(f"**Model:** `{MODEL}`")
    st.caption(key_info())
    if st.button("🔑 Test API key & model", use_container_width=True):
        with st.spinner("Contacting the provider..."):
            good, msg = check_llm(force=True)
        (st.success if good else st.error)(msg)
    st.write(f"**Allowed folders:** {', '.join(f'`{r}`' for r in ALLOWED_ROOTS)}")
    st.write(f"**Default downloads:** `{DOWNLOAD_DIR}`")
    st.caption("Emergency stop: press Stop, or slam the mouse into a screen corner (PyAutoGUI fail-safe).")
    follow_up = st.checkbox("Continue in the same ADK session (follow-up task)", value=False,
                            help="Keeps the conversation context of the previous task.")
    st.divider()
    st.markdown("**Example tasks**")
    EXAMPLES = [
        "Open https://the-internet.herokuapp.com/download, download the first .txt file and save it in ~/Documents/AgentTests",
        "Find the file report_draft.txt in ~/Downloads, rename it to report_final.txt and move it to ~/Documents/Archive",
        "Open ~/Documents/AgentTests/contacts.xlsx and add a row: Asha Rao, asha@example.com, Bengaluru",
        "Go to https://www.selenium.dev/selenium/web/web-form.html, fill the form with name Test User and stop before submitting for my approval",
        "Find invoice_march.pdf in ~/Downloads, rename it to invoice_final.pdf and move it to ~/Documents/Archive (the file may not exist - recover sensibly)",
    ]
    for i, ex in enumerate(EXAMPLES):
        if st.button(f"Example {i + 1}", key=f"ex{i}", use_container_width=True, disabled=ctrl.running):
            st.session_state["task_text"] = ex
            st.rerun()

# -------------------------------------------------------------------------- main
st.title("🖥️ Exora AI Desktop Automation Agent")
st.caption("Google ADK agent that operates your computer from plain-English instructions - with verification.")

left, right = st.columns([2, 3], gap="large")

with left:
    task = st.text_area("What should the agent do?", key="task_text", height=170, disabled=ctrl.running,
                        placeholder="e.g. Open example.com, download the annual report and save it in my Documents folder")
    c1, c2 = st.columns(2)
    if c1.button("▶ Start task", type="primary", use_container_width=True, disabled=ctrl.running or not task.strip()):
        ctrl.start(task, continue_session=follow_up)
        st.rerun()
    if c2.button("⏹ Stop task", use_container_width=True, disabled=not ctrl.running):
        ctrl.stop()
    st.info("Keep your hands off the mouse and keyboard while a desktop task runs - the agent is using them.")


@st.fragment(run_every=1.0)
def live_panel() -> None:
    snap = TRACKER.snapshot()
    if st.session_state.get("was_running") and not ctrl.running:
        st.session_state["was_running"] = False
        st.rerun()                                   # re-enable Start button / input
    st.session_state["was_running"] = ctrl.running

    level, text = STATUS_BADGE.get(snap["status"], ("info", snap["status"]))
    getattr(st, level)(f"**{text}**")
    if snap["summary"] and snap["status"] in ("success", "failed", "stopped"):
        st.write(snap["summary"])
        for ev in snap["evidence"]:
            st.code(ev, language=None)

    k = snap["counters"]
    elapsed = (snap["ended_at"] or time.time()) - snap["started_at"] if snap["started_at"] else 0
    m1, m2, m3, m4, m5 = st.columns(5)
    m1.metric("Tool calls", k["tool_calls"])
    m2.metric("Errors", k["errors"])
    m3.metric("Verifications", k["verifications"])
    m4.metric("LLM calls", k["llm_calls"])
    m5.metric("Seconds", f"{elapsed:.0f}")

    # ---- human approval checkpoint ----
    pending = APPROVAL.pending
    if pending and APPROVAL.decision is None:
        with st.container(border=True):
            st.warning("**Approval required before final submission**")
            st.write(pending["summary"])
            for line in pending["fields"]:
                st.markdown(f"- {line}")
            a, b = st.columns(2)
            if a.button("✅ Approve & submit", type="primary", key="approve", use_container_width=True):
                APPROVAL.decide(True)
            if b.button("🚫 Reject", key="reject", use_container_width=True):
                APPROVAL.decide(False)

    if snap["plan"]:
        with st.expander("Plan", expanded=True):
            for p in snap["plan"]:
                note = f" - _{p['note']}_" if p.get("note") else ""
                st.markdown(f"{PLAN_ICON.get(p['status'], '⬜')} **{p['n']}.** {p['step']}{note}")

    shot = snap["latest_screenshot"]
    if shot and Path(shot).exists():
        with st.expander("Latest screenshot", expanded=False):
            st.image(shot)

    st.subheader("Execution log")
    box = st.container(height=420)
    with box:
        for e in reversed(snap["entries"][-150:]):
            mark = "✅" if e.status == "success" else "❌" if e.status == "error" else ICONS.get(e.kind, "•")
            st.markdown(f"`{time.strftime('%H:%M:%S', time.localtime(e.ts))}` {mark} {e.message}")


with right:
    live_panel()
