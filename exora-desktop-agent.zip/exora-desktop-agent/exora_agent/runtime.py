"""Runs the ADK agent for one task at a time in a background thread (so the UI stays responsive).

Responsibilities
  * ADK Runner + SessionService (in-memory by default, SQLite if EXORA_SESSION_DB is set)
  * one ADK *session* per task (or a follow-up in the same session, keeping conversation memory)
  * streaming ADK events into the ExecutionTracker
  * Stop: sets the STOP flag (tools notice) AND cancels the asyncio task (aborts a pending LLM call)
  * computing the final status from the session state written by declare_task_complete
"""
import asyncio
import threading
import traceback
import uuid
from typing import Optional

from google.adk.agents.run_config import RunConfig
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

from .agent import root_agent
from .config import APP_NAME, MAX_LLM_CALLS, SESSION_DB, USER_ID
from .preflight import check_llm
from .tracking import APPROVAL, STOP, TRACKER


def _make_session_service():
    if SESSION_DB:
        try:
            from google.adk.sessions import DatabaseSessionService
            return DatabaseSessionService(db_url=SESSION_DB)
        except Exception as exc:  # noqa: BLE001 - fall back rather than refuse to start
            TRACKER.log("info", f"Persistent sessions unavailable ({exc}); using in-memory sessions.")
    return InMemorySessionService()


class AgentTaskController:
    """Start / stop / observe a single agent task. One instance per process (see ui.py)."""

    def __init__(self) -> None:
        self.session_service = _make_session_service()
        self.runner = Runner(agent=root_agent, app_name=APP_NAME, session_service=self.session_service)
        self._thread: Optional[threading.Thread] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._task: Optional[asyncio.Task] = None
        self.session_id: Optional[str] = None

    # ------------------------------------------------------------------ public API
    @property
    def running(self) -> bool:
        return self._thread is not None and self._thread.is_alive()

    def start(self, instruction: str, continue_session: bool = False) -> bool:
        """Begin a task. Returns False if one is already running or the instruction is empty."""
        if self.running or not instruction.strip():
            return False
        STOP.clear()
        APPROVAL.reset()
        if not (continue_session and self.session_id):
            self.session_id = uuid.uuid4().hex
            fresh = True
        else:
            fresh = False
        TRACKER.begin(instruction.strip(), self.session_id)
        self._thread = threading.Thread(target=self._thread_main, args=(instruction.strip(), fresh),
                                        name="exora-agent", daemon=True)
        self._thread.start()
        return True

    def stop(self) -> None:
        """Abort the running task as quickly as possible."""
        if not self.running:
            return
        STOP.set()
        APPROVAL.decide(False)                       # unblock a pending approval prompt
        TRACKER.set_status("stopping")
        TRACKER.log("system", "Stop requested by user...")
        if self._loop and self._task:
            self._loop.call_soon_threadsafe(self._task.cancel)

    # ------------------------------------------------------------------- internals
    def _thread_main(self, instruction: str, fresh_session: bool) -> None:
        try:
            asyncio.run(self._run(instruction, fresh_session))
        except Exception as exc:  # noqa: BLE001
            TRACKER.log("error", f"Runner crashed: {type(exc).__name__}: {exc}", status="error")
            TRACKER.log("error", traceback.format_exc()[-1200:], status="error")
            if TRACKER.status not in TRACKER.TERMINAL:
                TRACKER.finish("failed", f"Internal error: {type(exc).__name__}: {exc}")

    async def _run(self, instruction: str, fresh_session: bool) -> None:
        self._loop = asyncio.get_running_loop()
        self._task = asyncio.current_task()
        sid = self.session_id
        assert sid is not None
        try:
            # 1) fail fast on a bad key / model name (one clear message instead of 5 silent retries)
            good, msg = await self._loop.run_in_executor(None, check_llm)
            if not good:
                TRACKER.log("error", msg, status="error")
                TRACKER.finish("failed", msg)
                return
            # 2) session
            if fresh_session:
                await self.session_service.create_session(
                    app_name=APP_NAME, user_id=USER_ID, session_id=sid,
                    state={"task": instruction, "unverified_actions": [], "verifications": 0,
                           "failures": 0, "consecutive_failures": 0})
            else:
                session = await self.session_service.get_session(app_name=APP_NAME, user_id=USER_ID, session_id=sid)
                if session:
                    session.state.update({"task": instruction, "unverified_actions": [], "verifications": 0,
                                          "consecutive_failures": 0, "task_outcome": None})
            # 3) run, with automatic recovery from recoverable provider errors
            text, malformed, limited = instruction, 0, 0
            while True:
                try:
                    await self._stream(sid, text)
                    break
                except asyncio.CancelledError:
                    break                                   # Stop pressed while awaiting the model
                except Exception as exc:  # noqa: BLE001
                    if STOP.is_set():
                        break
                    low = str(exc).lower()
                    if ("tool_use_failed" in low or "failed to call a function" in low) and malformed < 3:
                        malformed += 1
                        TRACKER.log("error", f"Model produced a malformed tool call (attempt {malformed}/3) - asking it to retry.", status="error")
                        text = ("Your previous tool call was malformed and was rejected. Retry that same step now: call ONE tool, "
                                "with argument types exactly as in its schema (numbers as numbers, lists as JSON arrays).")
                        continue
                    if ("rate_limit" in low or "429" in low or "ratelimit" in low) and limited < 4:
                        limited += 1
                        wait_s = 20 * limited
                        TRACKER.log("error", f"Groq rate limit hit - waiting {wait_s}s, then continuing (retry {limited}/4).", status="error")
                        for _ in range(wait_s):
                            if STOP.is_set():
                                break
                            await asyncio.sleep(1)
                        text = "Continue the task from where you stopped. Do not repeat steps that already succeeded."
                        continue
                    TRACKER.log("error", f"Agent run failed: {type(exc).__name__}: {str(exc)[:500]}", status="error")
                    TRACKER.finish("failed", self._friendly(exc))
                    return
        except Exception as exc:  # noqa: BLE001 - e.g. session errors
            TRACKER.log("error", f"Agent run failed: {type(exc).__name__}: {str(exc)[:500]}", status="error")
            TRACKER.finish("failed", self._friendly(exc))
            return
        await self._finalise(sid)

    async def _stream(self, sid: str, text: str) -> None:
        message = types.Content(role="user", parts=[types.Part(text=text)])
        async for event in self.runner.run_async(
                user_id=USER_ID, session_id=sid, new_message=message,
                run_config=RunConfig(max_llm_calls=MAX_LLM_CALLS)):
            self._on_event(event)
            if STOP.is_set():
                break

    @staticmethod
    def _friendly(exc: Exception) -> str:
        low = str(exc).lower()
        if "invalid_api_key" in low or "invalid api key" in low or "api key not valid" in low:
            return "The API key was rejected by the provider. Create a new key, paste it into .env, restart Streamlit."
        if "model_not_found" in low or "does not exist" in low or "decommissioned" in low:
            return "The configured model is not available. Check EXORA_MODEL in .env."
        if "rate_limit" in low or "429" in low:
            return "Still rate-limited after retries. Wait a minute and press Start again, or use a higher Groq tier."
        if "tool_use_failed" in low:
            return "The model kept producing malformed tool calls. Press Start again, or try a larger/more reliable model."
        return f"Agent run failed: {type(exc).__name__}: {str(exc)[:300]}"

    def _on_event(self, event) -> None:
        if getattr(event, "error_message", None):
            TRACKER.log("error", f"Model error: {event.error_message}", status="error")
        content = getattr(event, "content", None)
        if not content or not content.parts or getattr(event, "partial", False):
            return
        for part in content.parts:
            if part.text and not getattr(part, "thought", False) and event.author != "user":
                TRACKER.log("agent", part.text.strip())

    async def _finalise(self, sid: str) -> None:
        """Decide the final status from ADK session state (the source of truth)."""
        if TRACKER.status in ("success", "failed") and TRACKER.ended_at:
            return                                      # declare_task_complete already recorded it
        if STOP.is_set():
            TRACKER.finish("stopped", "Stopped by the user.")
            return
        session = await self.session_service.get_session(app_name=APP_NAME, user_id=USER_ID, session_id=sid)
        outcome = (session.state.get("task_outcome") if session else None)
        if outcome:
            TRACKER.finish("success" if outcome["success"] else "failed", outcome["summary"], outcome["evidence"])
        else:
            TRACKER.finish("failed", "The agent stopped without a verified completion (declare_task_complete was never "
                                     "accepted). Treat the task as NOT completed.")
