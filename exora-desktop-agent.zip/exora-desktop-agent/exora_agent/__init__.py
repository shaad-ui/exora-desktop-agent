"""Exora AI Desktop Automation Agent (Google ADK)."""
from . import agent  # noqa: F401  (lets `adk web` discover root_agent)
