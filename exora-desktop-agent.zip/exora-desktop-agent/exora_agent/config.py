"""Central configuration. Everything tunable lives here and is read from env / .env."""
import os
from pathlib import Path

from dotenv import load_dotenv

# Load the .env that sits next to ui.py, and let it WIN over stale system environment variables.
load_dotenv(Path(__file__).resolve().parent.parent / ".env", override=True)


def _clean_key(name: str) -> None:
    """Strip accidental quotes/spaces/newlines around an API key."""
    v = os.environ.get(name)
    if v:
        c = v.strip().strip('"').strip("'").strip()
        if c != v:
            os.environ[name] = c


for _k in ("GROQ_API_KEY", "GOOGLE_API_KEY", "GEMINI_API_KEY"):
    _clean_key(_k)


def _flag(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).strip().lower() in ("1", "true", "yes", "on")


def _path(value: str) -> Path:
    return Path(os.path.expandvars(os.path.expanduser(value))).resolve()


APP_NAME = "exora_desktop_agent"
USER_ID = "local_user"

# Any LiteLLM model string works ("groq/llama-3.3-70b-versatile"); names starting with "gemini" use ADK's native Gemini.
MODEL = os.getenv("EXORA_MODEL", "groq/llama-3.3-70b-versatile")
# Can the model SEE images? Llama 3.3 70B cannot. Set true only for a vision model
# (e.g. groq/meta-llama/llama-4-scout-17b-16e-instruct or any gemini-* model).
MODEL_VISION = _flag("EXORA_MODEL_VISION", MODEL.startswith("gemini"))
MAX_LLM_CALLS = int(os.getenv("EXORA_MAX_LLM_CALLS", "80"))
SESSION_DB = os.getenv("EXORA_SESSION_DB", "").strip()

# --- File-system sandbox: tools refuse paths outside these roots -------------
ALLOWED_ROOTS = [
    _path(p) for p in os.getenv("EXORA_ALLOWED_ROOTS", "~").split(os.pathsep) if p.strip()
]
DOWNLOAD_DIR = _path(os.getenv("EXORA_DOWNLOAD_DIR", "~/Downloads"))

# --- Browser ---------------------------------------------------------------
BROWSER_CHANNEL = os.getenv("EXORA_BROWSER_CHANNEL", "").strip()  # "chrome", "msedge" or ""
BROWSER_HEADLESS = _flag("EXORA_BROWSER_HEADLESS", False)
BROWSER_ACTION_TIMEOUT_MS = 15_000
BROWSER_NAV_TIMEOUT_MS = 30_000

# --- Screen observation -------------------------------------------------------
SCREENSHOT_MAX_WIDTH = 1280      # downscale before sending to the model
SCREENSHOT_GRID = True           # overlay a labelled coordinate grid (helps click accuracy)
SCREENSHOT_DIR = _path(os.getenv("EXORA_SCREENSHOT_DIR", "./runs/screenshots"))
ACTION_PAUSE_S = 0.6             # settle time after GUI actions

# --- Guard rails ------------------------------------------------------------
APPROVAL_TIMEOUT_S = 15 * 60     # how long to wait for the human to approve a submission
MAX_IDENTICAL_CALLS = 3          # loop breaker: same tool+args this many times in a row

# Shrink tool descriptions sent to non-Gemini models (saves ~40% of tokens; matters on Groq's small rate limits)
SLIM_TOOLS = _flag("EXORA_SLIM_TOOLS", not MODEL.startswith("gemini"))
