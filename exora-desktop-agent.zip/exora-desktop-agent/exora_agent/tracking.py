"""Thread-safe execution tracking, stop signalling and the human-approval gate.

The ADK agent runs in a background thread/event loop while the Streamlit UI polls
these objects from another thread, so every shared structure is lock-protected.
"""
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Optional

# --------------------------------------------------------------------------- stop
STOP = threading.Event()


class TaskStopped(Exception):
    """Raised inside tools when the user pressed Stop."""


def ensure_not_stopped() -> None:
    if STOP.is_set():
        raise TaskStopped("Task was stopped by the user.")


# ------------------------------------------------------------------------ tracker
@dataclass
class LogEntry:
    seq: int
    ts: float
    kind: str      # info | agent | plan | tool_call | tool_result | error | approval | system
    message: str
    status: str = ""   # success | error | ""
    data: dict = field(default_factory=dict)


class ExecutionTracker:
    """Records everything the agent does: status, plan, step log, counters, evidence."""

    TERMINAL = ("success", "failed", "stopped")

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self.reset()

    def reset(self) -> None:
        with self._lock:
            self.status = "idle"            # idle|running|awaiting_approval|stopping|success|failed|stopped
            self.task = ""
            self.session_id = ""
            self.started_at: Optional[float] = None
            self.ended_at: Optional[float] = None
            self.entries: list[LogEntry] = []
            self.plan: list[dict] = []
            self.summary = ""
            self.evidence: list[str] = []
            self.latest_screenshot: Optional[str] = None
            self.counters = {"tool_calls": 0, "errors": 0, "llm_calls": 0, "verifications": 0}

    def begin(self, task: str, session_id: str) -> None:
        self.reset()
        with self._lock:
            self.task, self.session_id = task, session_id
            self.status, self.started_at = "running", time.time()
        self.log("system", f"Task started (session {session_id[:8]}): {task}")

    def log(self, kind: str, message: str, status: str = "", **data: Any) -> None:
        with self._lock:
            self.entries.append(LogEntry(len(self.entries) + 1, time.time(), kind, message, status, data))

    def set_status(self, status: str) -> None:
        with self._lock:
            if self.status not in self.TERMINAL:
                self.status = status

    def set_plan(self, plan: list[dict]) -> None:
        with self._lock:
            self.plan = [dict(p) for p in plan]

    def set_screenshot(self, path: str) -> None:
        with self._lock:
            self.latest_screenshot = path

    def bump(self, counter: str, n: int = 1) -> None:
        with self._lock:
            self.counters[counter] = self.counters.get(counter, 0) + n

    def finish(self, status: str, summary: str = "", evidence: Optional[list] = None) -> None:
        with self._lock:
            self.status, self.ended_at = status, time.time()
            self.summary = summary or self.summary
            self.evidence = list(evidence or self.evidence)
        self.log("system", f"Task finished: {status.upper()} - {summary}",
                 status="success" if status == "success" else "error")

    def snapshot(self) -> dict:
        with self._lock:
            return {
                "status": self.status, "task": self.task, "session_id": self.session_id,
                "started_at": self.started_at, "ended_at": self.ended_at,
                "entries": list(self.entries), "plan": [dict(p) for p in self.plan],
                "summary": self.summary, "evidence": list(self.evidence),
                "latest_screenshot": self.latest_screenshot, "counters": dict(self.counters),
            }


# --------------------------------------------------------------------- approval
class ApprovalGate:
    """Human-in-the-loop checkpoint for irreversible actions (form submission etc.).

    Flow: agent calls request_user_approval -> gate.request() -> UI shows Approve/Reject
    -> gate.decide() -> tool resumes. An approval produces ONE single-use *grant* that the
    browser tools require before clicking a submit-like control, so the guarantee is
    enforced in code, not just in the prompt.
    """

    GRANT_TTL_S = 300

    def __init__(self) -> None:
        self._lock = threading.RLock()
        self.reset()

    def reset(self) -> None:
        with self._lock:
            self.pending: Optional[dict] = None
            self.decision: Optional[bool] = None
            self._grant_until = 0.0

    def request(self, summary: str, fields: list[str]) -> None:
        with self._lock:
            self.pending = {"summary": summary, "fields": list(fields), "ts": time.time()}
            self.decision = None

    def decide(self, approved: bool) -> None:
        with self._lock:
            if self.pending is not None:
                self.decision = approved

    def grant(self) -> None:
        with self._lock:
            self._grant_until = time.time() + self.GRANT_TTL_S
            self.pending = None

    def clear_request(self) -> None:
        with self._lock:
            self.pending, self.decision = None, None

    def grant_available(self) -> bool:
        with self._lock:
            return time.time() < self._grant_until

    def consume_grant(self) -> bool:
        with self._lock:
            ok = time.time() < self._grant_until
            self._grant_until = 0.0
            return ok


TRACKER = ExecutionTracker()
APPROVAL = ApprovalGate()
