"""Fail-fast checks so a bad key / wrong model name produces ONE clear message instead of five silent retries."""
import json
import os
import time
import urllib.error
import urllib.request

from .config import MODEL

_cache = {"ok_until": 0.0}


def mask(key: str) -> str:
    return f"{key[:4]}...{key[-4:]} ({len(key)} chars)" if key else "NOT SET"


def key_info() -> str:
    """Short human description of the key the app is actually using (safe to display)."""
    if MODEL.startswith("groq/"):
        return "GROQ_API_KEY = " + mask(os.getenv("GROQ_API_KEY", ""))
    return "GOOGLE_API_KEY = " + mask(os.getenv("GOOGLE_API_KEY", "") or os.getenv("GEMINI_API_KEY", ""))


def check_llm(force: bool = False) -> tuple:
    """Return (ok, message). Validates the Groq key AND that the configured model exists for it."""
    if not force and time.time() < _cache["ok_until"]:
        return True, "cached"
    if not MODEL.startswith("groq/"):
        return True, "Preflight skipped for non-Groq models."
    key = os.getenv("GROQ_API_KEY", "")
    if not key:
        return False, ("GROQ_API_KEY is not set. Create a file named exactly '.env' in the folder that contains ui.py "
                       "with the line GROQ_API_KEY=gsk_..., then restart Streamlit.")
    if not key.startswith("gsk_"):
        return False, (f"GROQ_API_KEY ({mask(key)}) does not look like a Groq key - Groq keys start with 'gsk_'. "
                       "You probably left the placeholder or pasted a key from another service. "
                       "Create a key at https://console.groq.com/keys and paste it into .env.")
    req = urllib.request.Request("https://api.groq.com/openai/v1/models",
                                 headers={"Authorization": f"Bearer {key}", "User-Agent": "exora-agent/1.0"})
    try:
        with urllib.request.urlopen(req, timeout=12) as resp:
            ids = [m.get("id", "") for m in json.load(resp).get("data", [])]
    except urllib.error.HTTPError as exc:
        if exc.code == 401:
            return False, (f"Groq rejected the key {mask(key)} (401 invalid_api_key). Create a NEW key at "
                           "https://console.groq.com/keys, paste it into .env with no quotes/spaces, restart Streamlit.")
        if exc.code == 429:
            return True, "Key accepted (Groq is rate-limiting right now; the agent will back off and retry)."
        return False, f"Groq answered HTTP {exc.code} while checking the key."
    except Exception as exc:  # noqa: BLE001 - offline, proxy, DNS...
        return False, f"Could not reach Groq to check the key ({type(exc).__name__}: {exc}). Check your internet connection."
    name = MODEL.split("/", 1)[1]
    if ids and name not in ids:
        similar = [i for i in ids if "llama" in i][:8]
        return False, (f"Key is valid but model '{name}' is not available to it. Set EXORA_MODEL=groq/<one of>: "
                       f"{', '.join(similar) or ', '.join(ids[:8])}")
    _cache["ok_until"] = time.time() + 600
    return True, f"Groq key {mask(key)} is valid; model '{name}' is available."
