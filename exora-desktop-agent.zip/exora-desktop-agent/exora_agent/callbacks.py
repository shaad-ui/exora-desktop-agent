"""ADK callbacks: execution tracking, loop protection and the programmatic verification gate.

before_model_callback  - attaches the freshest screenshot to the LLM request (the agent's "eyes")
before_tool_callback   - logs the call, honours Stop, breaks infinite loops
after_tool_callback    - logs the result, maintains session state used by declare_task_complete:
                           state['unverified_actions']  actions not yet proven by an observation
                           state['verifications']       number of successful verifications
                           state['consecutive_failures'] escalates to re-planning
"""
import json
from typing import Optional

from google.adk.agents.callback_context import CallbackContext
from google.adk.models import LlmRequest, LlmResponse
from google.adk.tools.base_tool import BaseTool
from google.adk.tools import ToolContext
from google.genai import types

from .config import MAX_IDENTICAL_CALLS, MODEL, MODEL_VISION, SLIM_TOOLS
from .tools import ACTION_TOOLS, VERIFIER_TOOLS, vision
from .tools.common import fail
from .tracking import STOP, TRACKER

# Observation tools may legitimately repeat with identical arguments
_REPEAT_OK = {"observe_screen", "browser_get_page_state", "browser_screenshot", "wait", "wait_for_file",
              "browser_wait_for", "file_exists", "list_windows", "browser_list_tabs", "browser_verify"}


def _short(obj, limit: int = 160) -> str:
    text = json.dumps(obj, default=str, ensure_ascii=False)
    return text if len(text) <= limit else text[:limit] + "..."


def _slim_schema(node) -> None:
    """Recursively drop 'title' and shorten 'description' in a JSON schema dict (token saver)."""
    if isinstance(node, dict):
        node.pop("title", None)
        if isinstance(node.get("description"), str):
            node["description"] = node["description"].split("\n")[0][:80]
        for v in node.values():
            _slim_schema(v)
    elif isinstance(node, list):
        for v in node:
            _slim_schema(v)


def _slim_tools(llm_request: LlmRequest) -> None:
    for tool in (llm_request.config.tools or []) if llm_request.config else []:
        for fd in getattr(tool, "function_declarations", None) or []:
            if fd.description:
                fd.description = fd.description.strip().split("\n\n")[0].replace("\n", " ")[:230]
            schema = getattr(fd, "parameters_json_schema", None)
            if isinstance(schema, dict):
                _slim_schema(schema)


# ------------------------------------------------------------------ model callback
def before_model(callback_context: CallbackContext, llm_request: LlmRequest) -> Optional[LlmResponse]:
    TRACKER.bump("llm_calls")
    if SLIM_TOOLS:
        _slim_tools(llm_request)
    if not MODEL.startswith("gemini"):
        from .llm_sanitizer import strip_thought_parts   # layer 1: no thinking blocks in history
        strip_thought_parts(llm_request.contents)
    png = vision.take_pending()
    if png and MODEL_VISION:
        llm_request.contents.append(types.Content(role="user", parts=[
            types.Part(text="[Latest screenshot requested by your last observation tool]"),
            types.Part.from_bytes(data=png, mime_type="image/png"),
        ]))
    return None          # None = continue with the (modified) request


# -------------------------------------------------------------------- tool callbacks
def before_tool(tool: BaseTool, args: dict, tool_context: ToolContext) -> Optional[dict]:
    if STOP.is_set():
        return fail("Task was stopped by the user.", stopped=True)

    key = f"{tool.name}:{json.dumps(args, sort_keys=True, default=str)}"
    recent = list(tool_context.state.get("recent_calls", []))
    if tool.name not in _REPEAT_OK and recent[-(MAX_IDENTICAL_CALLS - 1):].count(key) == MAX_IDENTICAL_CALLS - 1:
        TRACKER.log("error", f"Loop detected: {tool.name} repeated {MAX_IDENTICAL_CALLS}x with identical arguments", status="error")
        return fail(f"Loop detected: you called {tool.name} with identical arguments {MAX_IDENTICAL_CALLS} times in a row.",
                    hint="This approach is not working. Re-observe the state and change strategy (different tool, "
                         "selector or path), or call set_plan with a new plan, or finish with success=false.")
    tool_context.state["recent_calls"] = (recent + [key])[-6:]

    TRACKER.bump("tool_calls")
    TRACKER.log("tool_call", f"{tool.name}({_short(args)})", **{"tool": tool.name})
    return None          # None = run the real tool


def after_tool(tool: BaseTool, args: dict, tool_context: ToolContext, tool_response: dict) -> Optional[dict]:
    resp = tool_response if isinstance(tool_response, dict) else {"result": tool_response}
    state = tool_context.state
    success = resp.get("status") == "success"
    name = tool.name

    # ---- verification state machine (read by declare_task_complete) ----
    unverified = list(state.get("unverified_actions", []))
    if not success:
        state["failures"] = int(state.get("failures", 0)) + 1
        state["consecutive_failures"] = int(state.get("consecutive_failures", 0)) + 1
        TRACKER.bump("errors")
    else:
        state["consecutive_failures"] = 0
        self_verified = resp.get("verified") is True
        if name in VERIFIER_TOOLS and resp.get("verified") is not False:
            state["verifications"] = int(state.get("verifications", 0)) + 1
            TRACKER.bump("verifications")
            unverified = []                              # a fresh observation proves the current state
        elif name in ACTION_TOOLS:
            if self_verified:
                state["verifications"] = int(state.get("verifications", 0)) + 1
                TRACKER.bump("verifications")
            else:
                unverified.append(name)
        if resp.get("verified") is False and name in ACTION_TOOLS:
            unverified.append(f"{name} (self-check failed)")
        state["unverified_actions"] = unverified
    state["steps_executed"] = int(state.get("steps_executed", 0)) + 1

    # ---- log result for the UI ----
    if resp.get("screenshot_path"):
        TRACKER.set_screenshot(resp["screenshot_path"])
    if success:
        extra = ""
        if resp.get("verified") is True:
            extra = "  [verified]"
        elif resp.get("verified") is False:
            extra = "  [NOT verified]"
        TRACKER.log("tool_result", f"{name} -> OK{extra}  {_short({k: v for k, v in resp.items() if k not in ('status', 'elements', 'visible_text')}, 220)}",
                    status="success", tool=name)
    else:
        TRACKER.log("tool_result", f"{name} -> ERROR: {resp.get('error', '')[:200]}  | hint: {resp.get('hint', '')[:160]}",
                    status="error", tool=name)

    # ---- escalate repeated failures ----
    if not success and int(state.get("consecutive_failures", 0)) >= 4:
        escalated = dict(resp)
        escalated["escalation"] = ("4+ consecutive failures. STOP repeating. Call observe_screen or browser_get_page_state, "
                                   "re-plan with set_plan using a different approach, or finish with success=false.")
        return escalated
    return None          # None = keep the original tool response
