"""Tool registry: every callable here is wrapped by ADK as a FunctionTool and exposed to the agent."""
from .browser import (browser_click, browser_close, browser_dismiss_popups, browser_download_url,
                      browser_download_via_click, browser_extract_links, browser_extract_table,
                      browser_extract_text, browser_fill, browser_get_page_state, browser_go_back,
                      browser_list_tabs, browser_open_url, browser_press_key, browser_screenshot,
                      browser_scroll, browser_select_option, browser_set_checkbox, browser_switch_tab,
                      browser_verify, browser_wait_for)
from .computer import (click, focus_window, hotkey, list_windows, observe_screen, open_application,
                       open_path, press_key, scroll, type_text, wait)
from .control import declare_task_complete, request_user_approval, set_plan, update_plan_step
from .files import (create_directory, file_exists, list_directory, move_file, read_text_file,
                    rename_file, search_files, wait_for_file, write_text_file)
from .spreadsheet import (spreadsheet_create, spreadsheet_read, spreadsheet_verify_cell,
                          spreadsheet_write_cell, spreadsheet_write_row)

# ---- classification used by the verification state machine in callbacks.py -------------------
# Tools that CHANGE the world but do not prove it themselves (unless they return verified=True):
ACTION_TOOLS = {
    "click", "type_text", "press_key", "hotkey", "open_application", "open_path", "focus_window",
    "browser_open_url", "browser_click", "browser_press_key", "browser_go_back", "browser_dismiss_popups",
    "browser_switch_tab", "browser_select_option", "browser_set_checkbox", "browser_fill",
    "browser_download_via_click", "browser_download_url",
    "rename_file", "move_file", "create_directory", "write_text_file",
    "spreadsheet_create", "spreadsheet_write_cell", "spreadsheet_write_row",
}
# Tools that OBSERVE / PROVE the state of the world:
VERIFIER_TOOLS = {
    "observe_screen", "browser_screenshot", "browser_get_page_state", "browser_verify", "file_exists",
    "wait_for_file", "list_directory", "read_text_file", "spreadsheet_read", "spreadsheet_verify_cell",
    "browser_extract_text", "list_windows", "browser_list_tabs",
}

ALL_TOOLS = [
    # planning / control
    set_plan, update_plan_step, request_user_approval, declare_task_complete,
    # computer
    observe_screen, click, type_text, press_key, hotkey, scroll, wait, open_application, open_path,
    list_windows, focus_window,
    # browser
    browser_open_url, browser_get_page_state, browser_click, browser_fill, browser_select_option,
    browser_set_checkbox, browser_press_key, browser_scroll, browser_wait_for, browser_dismiss_popups,
    browser_go_back, browser_list_tabs, browser_switch_tab, browser_screenshot, browser_close,
    browser_extract_text, browser_extract_links, browser_extract_table, browser_verify,
    browser_download_via_click, browser_download_url,
    # files
    search_files, list_directory, file_exists, wait_for_file, create_directory, rename_file, move_file,
    read_text_file, write_text_file,
    # spreadsheets
    spreadsheet_create, spreadsheet_read, spreadsheet_write_cell, spreadsheet_write_row, spreadsheet_verify_cell,
]
