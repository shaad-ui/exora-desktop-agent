"""Native desktop interaction: observe screen, mouse, keyboard, windows, launching apps.

pyautogui is imported lazily so the package can be imported on machines without a display
(CI, unit tests). Coordinates the model gives are in *screenshot* pixels; they are scaled to real
screen coordinates using the ratio recorded by observe_screen (handles HiDPI / downscaling).
"""
import io
import os
import platform
import re
import shutil
import subprocess
import time
from datetime import datetime
from typing import Optional

from . import vision
from .common import fail, ok, resolve_path, safe_tool
from ..config import MODEL_VISION, ACTION_PAUSE_S, SCREENSHOT_DIR, SCREENSHOT_GRID, SCREENSHOT_MAX_WIDTH
from ..tracking import TRACKER, ensure_not_stopped

_SYSTEM = platform.system()          # 'Windows' | 'Darwin' | 'Linux'
_pg = None


def _pyautogui():
    global _pg
    if _pg is None:
        if _SYSTEM == "Windows":
            try:                      # make coordinates match real pixels on scaled displays
                import ctypes
                ctypes.windll.user32.SetProcessDPIAware()
            except Exception:         # noqa: BLE001
                pass
        import pyautogui
        pyautogui.FAILSAFE = True     # slam mouse into a corner = emergency abort
        pyautogui.PAUSE = 0.15
        _pg = pyautogui
    return _pg


def _to_screen(x: int, y: int):
    """Screenshot pixel -> real screen coordinate, with bounds checking."""
    if not vision.is_calibrated():
        raise ValueError("No calibrated screenshot yet. Call observe_screen first so coordinates can be mapped.")
    pg = _pyautogui()
    sx, sy = vision.get_scale()
    rx, ry = int(round(x * sx)), int(round(y * sy))
    w, h = pg.size()
    if not (0 <= rx < w and 0 <= ry < h):
        raise ValueError(f"({x},{y}) is outside the screenshot (screen is {w}x{h}).")
    return rx, ry


def _draw_grid(img):
    from PIL import Image, ImageDraw
    overlay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(overlay)
    for gx in range(0, img.width, 100):
        d.line([(gx, 0), (gx, img.height)], fill=(255, 0, 0, 70), width=1)
        d.text((gx + 2, 2), str(gx), fill=(255, 0, 0, 230))
    for gy in range(0, img.height, 100):
        d.line([(0, gy), (img.width, gy)], fill=(255, 0, 0, 70), width=1)
        d.text((2, gy + 2), str(gy), fill=(255, 0, 0, 230))
    return Image.alpha_composite(img.convert("RGBA"), overlay).convert("RGB")


@safe_tool
def observe_screen(show_grid: bool = True) -> dict:
    """OBSERVE the desktop: take a screenshot that you will see on your next turn.
    Coordinates for click() refer to this image (a red 100px grid with labels helps you aim).
    Call it before GUI actions and again after them to confirm the result.

    Args:
        show_grid: Overlay a labelled coordinate grid on the screenshot.
    """
    if not MODEL_VISION:                       # text-only model: report windows instead of pixels
        try:
            titles = _window_titles()
        except Exception as exc:  # noqa: BLE001
            titles = [f"(window list unavailable: {exc})"]
        return ok(vision=False, open_windows=titles[:40],
                  note="The current model cannot see images. Use list_windows/file tools/browser_get_page_state to verify state.")
    pg = _pyautogui()
    img = pg.screenshot().convert("RGB")
    logical_w, logical_h = pg.size()
    if img.width > SCREENSHOT_MAX_WIDTH:
        ratio = SCREENSHOT_MAX_WIDTH / img.width
        img = img.resize((SCREENSHOT_MAX_WIDTH, int(img.height * ratio)))
    vision.set_scale(logical_w / img.width, logical_h / img.height)
    if show_grid and SCREENSHOT_GRID:
        img = _draw_grid(img)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)
    path = SCREENSHOT_DIR / f"screen_{datetime.now():%H%M%S_%f}.png"
    path.write_bytes(buf.getvalue())
    vision.set_pending(buf.getvalue())
    TRACKER.set_screenshot(str(path))
    return ok(image_width=img.width, image_height=img.height, screenshot_path=str(path),
              note="Screenshot is attached to the next message. Use its pixel coordinates for click().")


@safe_tool
def click(x: int, y: int, button: str = "left", double: bool = False) -> dict:
    """Click at a position of the LAST screenshot (pixel coordinates in that image).

    Args:
        x: Horizontal pixel in the screenshot.
        y: Vertical pixel in the screenshot.
        button: 'left', 'right' or 'middle'.
        double: Double-click (e.g. to open a file).
    """
    if not MODEL_VISION:
        return fail("Pixel clicking is disabled: the current model cannot see the screen.",
                    hint="Use keyboard control (focus_window, hotkey, press_key, type_text) or the browser_* tools.")
    pg = _pyautogui()
    rx, ry = _to_screen(x, y)
    pg.moveTo(rx, ry, duration=0.25)
    pg.click(button=button, clicks=2 if double else 1)
    time.sleep(ACTION_PAUSE_S)
    return ok(clicked=[x, y], note="Now call observe_screen to confirm the UI reacted.")


@safe_tool
def type_text(text: str, press_enter: bool = False) -> dict:
    """Type text into the currently focused control. Click the field first.

    Args:
        text: Text to type.
        press_enter: Press Enter afterwards.
    """
    pg = _pyautogui()
    if text.isascii():
        pg.write(text, interval=0.02)
    else:                                                   # unicode: paste via clipboard
        import pyperclip
        pyperclip.copy(text)
        pg.hotkey("command" if _SYSTEM == "Darwin" else "ctrl", "v")
    if press_enter:
        pg.press("enter")
    time.sleep(ACTION_PAUSE_S)
    return ok(typed_chars=len(text), pressed_enter=press_enter)


@safe_tool
def press_key(key: str) -> dict:
    """Press one key, e.g. 'enter', 'tab', 'esc', 'down', 'f5', 'delete'.

    Args:
        key: PyAutoGUI key name.
    """
    pg = _pyautogui()
    if key.lower() not in pg.KEYBOARD_KEYS:
        return fail(f"Unknown key '{key}'.", hint="Use names such as enter, tab, esc, up, down, left, right, f1..f12, backspace.")
    pg.press(key.lower())
    time.sleep(ACTION_PAUSE_S / 2)
    return ok(pressed=key)


@safe_tool
def hotkey(keys: list[str]) -> dict:
    """Press a key combination, e.g. ['ctrl','l'] focus address bar, ['ctrl','s'] save, ['alt','tab'] switch window.
    On macOS use 'command' instead of 'ctrl'.

    Args:
        keys: Keys pressed together, in order.
    """
    pg = _pyautogui()
    bad = [k for k in keys if k.lower() not in pg.KEYBOARD_KEYS]
    if bad:
        return fail(f"Unknown keys: {bad}")
    pg.hotkey(*[k.lower() for k in keys])
    time.sleep(ACTION_PAUSE_S)
    return ok(pressed="+".join(keys))


@safe_tool
def scroll(amount: int) -> dict:
    """Scroll the window under the mouse. Positive = up, negative = down (about 100 per notch).

    Args:
        amount: Scroll clicks; e.g. -500 scrolls down a page.
    """
    _pyautogui().scroll(int(amount))
    time.sleep(ACTION_PAUSE_S / 2)
    return ok(scrolled=amount)


@safe_tool
def wait(seconds: float) -> dict:
    """Wait for a slow application/page (max 30 s per call). Stop-aware.

    Args:
        seconds: Seconds to wait.
    """
    end = time.time() + min(max(float(seconds), 0.1), 30)
    while time.time() < end:
        ensure_not_stopped()
        time.sleep(0.25)
    return ok(waited=seconds)


# ------------------------------------------------------------ launching / windows
_ALIASES = {
    "chrome": {"Windows": "chrome", "Darwin": "Google Chrome", "Linux": "google-chrome"},
    "firefox": {"Windows": "firefox", "Darwin": "Firefox", "Linux": "firefox"},
    "edge": {"Windows": "msedge", "Darwin": "Microsoft Edge", "Linux": "microsoft-edge"},
    "excel": {"Windows": "excel", "Darwin": "Microsoft Excel", "Linux": "libreoffice --calc"},
    "notepad": {"Windows": "notepad", "Darwin": "TextEdit", "Linux": "gedit"},
    "calculator": {"Windows": "calc", "Darwin": "Calculator", "Linux": "gnome-calculator"},
    "explorer": {"Windows": "explorer", "Darwin": "Finder", "Linux": "xdg-open ."},
    "terminal": {"Windows": "wt", "Darwin": "Terminal", "Linux": "gnome-terminal"},
}
_SAFE_NAME = re.compile(r"^[\w\s.\-+()]+$")


@safe_tool
def open_application(name: str) -> dict:
    """Launch a desktop application by common name ('chrome', 'excel', 'notepad', 'calculator', 'explorer',
    'terminal') or by executable/app name. Afterwards call observe_screen to confirm the window appeared.

    Args:
        name: Application name.
    """
    key = name.strip().lower()
    target = _ALIASES.get(key, {}).get(_SYSTEM, name.strip())
    if not _SAFE_NAME.match(name.strip()):          # user input is never passed through a shell
        return fail("Application name contains unsupported characters.")
    if _SYSTEM == "Darwin":
        cmd = ["open", "-a", target]
    elif _SYSTEM == "Windows":
        exe = shutil.which(target)
        cmd = [exe] if exe else ["cmd", "/c", "start", "", target]
    else:
        parts = target.split()
        cmd = parts if shutil.which(parts[0]) else ["gtk-launch", target]
    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    time.sleep(2.0)
    rc = proc.poll()
    if rc not in (None, 0):
        return fail(f"Launching '{name}' failed (exit code {rc}).",
                    hint="Try another name (full app name or path), or use open_path for a file.")
    return ok(launched=name, command=" ".join(cmd), note="Verify with observe_screen that its window is visible.")


@safe_tool
def open_path(path: str) -> dict:
    """Open a file or folder with its default application (e.g. show a spreadsheet in Excel).

    Args:
        path: File or folder to open.
    """
    p = resolve_path(path, must_exist=True)
    if _SYSTEM == "Windows":
        os.startfile(str(p))                     # noqa: S606 - local, sandboxed path
    elif _SYSTEM == "Darwin":
        subprocess.Popen(["open", str(p)])
    else:
        subprocess.Popen(["xdg-open", str(p)])
    time.sleep(1.5)
    return ok(opened=str(p), note="Verify with observe_screen.")


def _window_titles() -> list:
    if _SYSTEM == "Windows":
        import pygetwindow as gw
        return [t for t in gw.getAllTitles() if t.strip()]
    if _SYSTEM == "Darwin":
        out = subprocess.run(["osascript", "-e",
                              'tell application "System Events" to get name of (processes where background only is false)'],
                             capture_output=True, text=True, timeout=10).stdout
        return [t.strip() for t in out.split(",") if t.strip()]
    if shutil.which("wmctrl"):
        out = subprocess.run(["wmctrl", "-l"], capture_output=True, text=True, timeout=10).stdout
        return [line.split(None, 3)[-1] for line in out.splitlines() if line.strip()]
    raise RuntimeError("Window listing needs 'wmctrl' on Linux (sudo apt install wmctrl).")


@safe_tool
def list_windows() -> dict:
    """List the titles of open application windows (use to check that an app really launched)."""
    titles = _window_titles()
    return ok(count=len(titles), windows=titles[:60])


@safe_tool
def focus_window(title_contains: str) -> dict:
    """Bring a window to the foreground by (part of) its title / app name.

    Args:
        title_contains: Case-insensitive part of the window title or application name.
    """
    needle = title_contains.lower()
    if _SYSTEM == "Windows":
        import pygetwindow as gw
        matches = [w for w in gw.getAllWindows() if needle in w.title.lower() and w.title.strip()]
        if not matches:
            return fail(f"No window matching '{title_contains}'.", hint="Call list_windows to see exact titles.")
        w = matches[0]
        if w.isMinimized:
            w.restore()
        w.activate()
        title: Optional[str] = w.title
    elif _SYSTEM == "Darwin":
        names = [t for t in _window_titles() if needle in t.lower()]
        if not names:
            return fail(f"No application matching '{title_contains}'.", hint="Call list_windows.")
        subprocess.run(["osascript", "-e", f'tell application "{names[0]}" to activate'], timeout=10)
        title = names[0]
    else:
        r = subprocess.run(["wmctrl", "-a", title_contains], capture_output=True, timeout=10)
        if r.returncode != 0:
            return fail(f"No window matching '{title_contains}'.")
        title = title_contains
    time.sleep(ACTION_PAUSE_S)
    return ok(focused=title, note="Verify with observe_screen.")
