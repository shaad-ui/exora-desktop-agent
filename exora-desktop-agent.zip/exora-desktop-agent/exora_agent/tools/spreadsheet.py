"""Spreadsheet (.xlsx) tools built on openpyxl. Every write re-opens the file from disk and
compares the stored value, so verified=True means the data is really in the saved file."""
from datetime import date, datetime
from typing import Any

from openpyxl import Workbook, load_workbook

from .common import fail, ok, resolve_path, safe_tool


def _jsonable(v: Any) -> Any:
    if v is None:
        return ""
    if isinstance(v, (datetime, date)):
        return v.isoformat()
    return v if isinstance(v, (str, int, float, bool)) else str(v)


def _coerce(value: str, as_number: bool) -> Any:
    if not as_number:
        return value
    try:
        f = float(value.replace(",", ""))
        return int(f) if f.is_integer() else f
    except ValueError:
        return value


def _sheet(wb, name: str):
    if name:
        if name not in wb.sheetnames:
            raise KeyError(f"Sheet '{name}' not found. Available: {wb.sheetnames}")
        return wb[name]
    return wb.active


def _same(a: Any, b: Any) -> bool:
    return str(a).strip() == str(b).strip() or (isinstance(a, (int, float)) and isinstance(b, (int, float)) and a == b)


@safe_tool
def spreadsheet_create(path: str, headers: list[str], sheet_name: str = "Sheet1") -> dict:
    """Create a new .xlsx workbook with an optional header row (fails if the file already exists).

    Args:
        path: Target .xlsx path.
        headers: Column headers for row 1 (pass an empty list for none).
        sheet_name: Name of the first sheet.
    """
    p = resolve_path(path)
    if p.suffix.lower() != ".xlsx":
        return fail("Only .xlsx files are supported.")
    if p.exists():
        return fail(f"'{p}' already exists.", hint="Use spreadsheet_write_row / spreadsheet_write_cell to edit it.")
    p.parent.mkdir(parents=True, exist_ok=True)
    wb = Workbook()
    wb.active.title = sheet_name
    if headers:
        wb.active.append(headers)
    wb.save(p)
    return ok(path=str(p), verified=p.exists())


@safe_tool
def spreadsheet_read(path: str, sheet_name: str = "", max_rows: int = 50) -> dict:
    """Read rows from an .xlsx file (also a verification step: shows what is really stored).

    Args:
        path: .xlsx file.
        sheet_name: Sheet to read (default: active sheet).
        max_rows: Maximum rows to return.
    """
    p = resolve_path(path, must_exist=True)
    wb = load_workbook(p, data_only=True)
    ws = _sheet(wb, sheet_name)
    rows = [[_jsonable(c) for c in row] for row in ws.iter_rows(min_row=1, max_row=max_rows, values_only=True)]
    return ok(path=str(p), sheets=wb.sheetnames, sheet=ws.title, total_rows=ws.max_row, rows=rows)


@safe_tool
def spreadsheet_write_cell(path: str, cell: str, value: str, sheet_name: str = "", as_number: bool = False) -> dict:
    """Write one cell (e.g. 'B3') and verify it by re-reading the saved file.

    Args:
        path: Existing .xlsx file.
        cell: Cell address such as 'A1'.
        value: Value to store.
        sheet_name: Sheet name (default: active sheet).
        as_number: Store as a number when the text is numeric.
    """
    p = resolve_path(path, must_exist=True)
    wb = load_workbook(p)
    ws = _sheet(wb, sheet_name)
    ws[cell] = _coerce(value, as_number)
    try:
        wb.save(p)
    except PermissionError:
        return fail("Cannot save: the workbook is open in another program.", hint="Close it in Excel, then retry.")
    stored = load_workbook(p)[ws.title][cell].value
    return ok(path=str(p), sheet=ws.title, cell=cell, stored_value=_jsonable(stored),
              verified=_same(stored, _coerce(value, as_number)))


@safe_tool
def spreadsheet_write_row(path: str, values: list[str], row: int = 0, start_column: int = 1,
                          sheet_name: str = "", numbers_as_numeric: bool = True) -> dict:
    """Write a full row of values (row=0 appends after the last used row) and verify by re-reading.

    Args:
        path: Existing .xlsx file.
        values: Cell values in column order.
        row: 1-based row number, or 0 to append to the first empty row.
        start_column: 1-based column where the first value goes.
        sheet_name: Sheet name (default: active sheet).
        numbers_as_numeric: Convert numeric-looking text to numbers.
    """
    p = resolve_path(path, must_exist=True)
    wb = load_workbook(p)
    ws = _sheet(wb, sheet_name)
    if row <= 0:
        last = ws.max_row
        while last >= 1 and all(c.value in (None, "") for c in ws[last]):
            last -= 1
        row = last + 1
    expected = [_coerce(v, numbers_as_numeric) for v in values]
    for i, v in enumerate(expected):
        ws.cell(row=row, column=start_column + i, value=v)
    try:
        wb.save(p)
    except PermissionError:
        return fail("Cannot save: the workbook is open in another program.", hint="Close it in Excel, then retry.")
    ws2 = load_workbook(p)[ws.title]
    stored = [ws2.cell(row=row, column=start_column + i).value for i in range(len(expected))]
    verified = all(_same(s, e) for s, e in zip(stored, expected))
    return ok(path=str(p), sheet=ws.title, row=row, stored_values=[_jsonable(s) for s in stored], verified=verified)


@safe_tool
def spreadsheet_verify_cell(path: str, cell: str, expected: str, sheet_name: str = "") -> dict:
    """VERIFICATION TOOL: confirm that a cell in the saved file holds the expected value.

    Args:
        path: .xlsx file.
        cell: Cell address.
        expected: Value that should be present.
        sheet_name: Sheet name (default: active sheet).
    """
    p = resolve_path(path, must_exist=True)
    ws = _sheet(load_workbook(p, data_only=True), sheet_name)
    actual = ws[cell].value
    good = _same(actual, expected)
    result = {"status": "success", "cell": cell, "expected": expected, "actual": _jsonable(actual), "verified": good}
    if not good:
        result["hint"] = "Value differs. Rewrite the cell and verify again."
    return result
