"""Meta-tools that make the agent *autonomous, plannable, safe and honest*:
  set_plan / update_plan_step          explicit planning, visible in the UI
  request_user_approval                human checkpoint before irreversible actions
  declare_task_complete                the ONLY way to finish; refuses success without verification
"""
import asyncio
import time

from google.adk.tools import ToolContext

from .common import fail, ok, safe_tool
from ..config import APPROVAL_TIMEOUT_S
from ..tracking import APPROVAL, TRACKER, ensure_not_stopped

_VALID = ("pending", "in_progress", "done", "failed", "skipped")


@safe_tool
def set_plan(steps: list[str], tool_context: ToolContext) -> dict:
    """Record your step-by-step plan BEFORE acting. Call again to re-plan after a failure.

    Args:
        steps: Ordered, concrete steps (each one verifiable), e.g. ['Open the site', 'Download the report', 'Verify file exists'].
    """
    plan = [{"n": i + 1, "step": s, "status": "pending", "note": ""} for i, s in enumerate(steps)]
    if plan:
        plan[0]["status"] = "in_progress"
    tool_context.state["plan"] = plan
    TRACKER.set_plan(plan)
    TRACKER.log("plan", "Plan: " + " -> ".join(f"{p['n']}. {p['step']}" for p in plan))
    return ok(steps=len(plan))


@safe_tool
def update_plan_step(step_number: int, status: str, note: str, tool_context: ToolContext) -> dict:
    """Update the status of one plan step as you progress.

    Args:
        step_number: 1-based step number from set_plan.
        status: One of pending, in_progress, done, failed, skipped.
        note: Short evidence or reason (e.g. the file path that was verified).
    """
    if status not in _VALID:
        return fail(f"status must be one of {_VALID}")
    plan = [dict(p) for p in tool_context.state.get("plan", [])]
    if not 1 <= step_number <= len(plan):
        return fail(f"No step {step_number}; plan has {len(plan)} steps.")
    plan[step_number - 1].update(status=status, note=note)
    tool_context.state["plan"] = plan          # reassign so ADK records the state delta
    TRACKER.set_plan(plan)
    return ok(step=step_number, status=status)


@safe_tool
async def request_user_approval(summary: str, field_values: list[str], tool_context: ToolContext) -> dict:
    """PAUSE and ask the human to approve before any irreversible action (form submit, purchase, send).
    Fill the form completely FIRST, then call this. Execution blocks until the user decides.

    Args:
        summary: What will happen if approved (e.g. 'Submit the contact form on example.com').
        field_values: Human-readable 'label: value' lines showing exactly what was entered.
    """
    APPROVAL.request(summary, field_values)
    TRACKER.set_status("awaiting_approval")
    TRACKER.log("approval", f"Waiting for user approval: {summary}")
    deadline = time.time() + APPROVAL_TIMEOUT_S
    try:
        while APPROVAL.decision is None:
            ensure_not_stopped()
            if time.time() > deadline:
                APPROVAL.clear_request()
                return fail("Approval timed out; nothing was submitted.", hint="Report that approval was not given.")
            await asyncio.sleep(0.5)                       # async sleep keeps the event loop (and Stop) responsive
        approved = bool(APPROVAL.decision)
    finally:
        TRACKER.set_status("running")
    if approved:
        APPROVAL.grant()
        TRACKER.log("approval", "User APPROVED the action.", status="success")
        return ok(approved=True, note="Approved. You may now click the final submit control ONCE, then verify the confirmation page.")
    APPROVAL.clear_request()
    TRACKER.log("approval", "User REJECTED the action.", status="error")
    return ok(approved=False, note="Rejected. Do NOT submit. Declare the task complete with success=false or as 'stopped before submission'.")


@safe_tool
def declare_task_complete(success: bool, summary: str, evidence: list[str], tool_context: ToolContext) -> dict:
    """Finish the task. This is the ONLY way to end a run. Success is REFUSED unless you have verified
    the outcome with a verification tool after your last action.

    Args:
        success: True only if the user's goal was fully achieved AND verified.
        summary: One or two sentences for the user.
        evidence: Concrete proof, e.g. ['file_exists: C:/Users/me/Documents/report.pdf, 52114 bytes'].
    """
    state = tool_context.state
    pending = list(state.get("unverified_actions", []))
    if success:
        if not evidence:
            return fail("Evidence is required to claim success.", hint="Run a verification tool and pass its result as evidence.")
        if int(state.get("verifications", 0)) == 0 or pending:
            return fail("REFUSED: success cannot be declared without verification after the last action.",
                        hint="Call a verifier (file_exists, wait_for_file, spreadsheet_verify_cell, browser_verify, "
                             "browser_get_page_state or observe_screen) and then declare again. "
                             f"Unverified actions: {pending}")
    state["task_outcome"] = {"success": bool(success), "summary": summary, "evidence": list(evidence)}
    TRACKER.finish("success" if success else "failed", summary, evidence)
    return ok(recorded=True, success=bool(success))
