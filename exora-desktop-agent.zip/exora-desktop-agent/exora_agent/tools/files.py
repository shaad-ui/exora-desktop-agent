"""File-system tools. All paths are sandboxed by resolve_path(); there is intentionally NO delete tool.
Every mutating tool re-checks the file system afterwards and reports verified=True/False."""
import fnmatch
import os
import shutil
import time
from datetime import datetime
from pathlib import Path

from .common import fail, ok, resolve_path, safe_tool
from ..tracking import ensure_not_stopped

_SKIP_DIRS = {".git", "node_modules", "__pycache__", "AppData", "Library", ".cache", ".venv", "venv",
              "site-packages", "$RECYCLE.BIN", "System Volume Information", ".Trash"}
_TEMP_SUFFIXES = (".crdownload", ".part", ".tmp", ".download", ".partial")


def _info(p: Path) -> dict:
    st = p.stat()
    return {"path": str(p), "name": p.name, "is_dir": p.is_dir(), "size_bytes": st.st_size,
            "modified": datetime.fromtimestamp(st.st_mtime).isoformat(timespec="seconds")}


@safe_tool
def search_files(query: str, directory: str = "~", extensions: str = "", max_results: int = 20) -> dict:
    """Search for files/folders by name under a directory (recursive, newest first).

    Args:
        query: Words that must all appear in the file name (case-insensitive), or a glob such as '*.pdf'.
        directory: Folder to search, e.g. '~/Documents' or 'Downloads'.
        extensions: Optional comma-separated filter such as '.pdf,.xlsx'.
        max_results: Maximum number of matches to return.
    """
    root = resolve_path(directory, must_exist=True)
    q = query.lower().strip()
    use_glob = any(c in q for c in "*?[")
    words = q.split()
    exts = tuple(e.strip().lower() if e.strip().startswith(".") else "." + e.strip().lower()
                 for e in extensions.split(",") if e.strip())
    deadline = time.time() + 25
    hits: list[Path] = []
    for dirpath, dirnames, filenames in os.walk(root):
        ensure_not_stopped()
        dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS and not d.startswith(".")]
        for name in filenames + dirnames:
            low = name.lower()
            if use_glob:
                good = fnmatch.fnmatch(low, q)
            else:
                good = all(w in low for w in words)
            if good and (not exts or low.endswith(exts)):
                hits.append(Path(dirpath) / name)
        if time.time() > deadline or len(hits) > 500:
            break
    hits.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    results = [_info(p) for p in hits[:max_results] if p.exists()]
    if not results:
        return fail(f"No match for '{query}' under {root}.",
                    hint="Try fewer/shorter words, a glob like '*report*', another folder, or list_directory.")
    return ok(count=len(results), truncated=len(hits) > max_results, matches=results)


@safe_tool
def list_directory(path: str, max_entries: int = 100) -> dict:
    """List the files and folders directly inside a directory (newest first).

    Args:
        path: Directory to list, e.g. '~/Downloads'.
        max_entries: Maximum entries to return.
    """
    d = resolve_path(path, must_exist=True)
    if not d.is_dir():
        return fail(f"'{d}' is not a directory.")
    items = sorted(d.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)
    return ok(directory=str(d), total=len(items), entries=[_info(p) for p in items[:max_entries]])


@safe_tool
def file_exists(path: str, min_size_bytes: int = 1) -> dict:
    """VERIFICATION TOOL: check that a file/folder really exists on disk and is not empty.

    Args:
        path: File or folder path.
        min_size_bytes: A file smaller than this is treated as NOT verified (default 1 = non-empty).
    """
    try:
        p = resolve_path(path)
    except PermissionError as exc:
        return fail(str(exc))
    if not p.exists():
        return {"status": "success", "exists": False, "verified": False, "path": str(p),
                "hint": "Not found. Use search_files to look for it elsewhere."}
    info = _info(p)
    good = p.is_dir() or info["size_bytes"] >= min_size_bytes
    return ok(exists=True, verified=good, **info)


@safe_tool
def wait_for_file(directory: str, name_contains: str = "", timeout_s: int = 30, max_age_s: int = 600) -> dict:
    """VERIFICATION TOOL: wait until a (recently modified) file appears in a folder and finishes writing.
    Useful after a download that was started by clicking in a GUI/browser.

    Args:
        directory: Folder to watch.
        name_contains: Optional text the file name must contain.
        timeout_s: Seconds to wait before giving up.
        max_age_s: Ignore files older than this many seconds.
    """
    d = resolve_path(directory, must_exist=True)
    end = time.time() + min(max(timeout_s, 1), 120)
    last_seen: dict = {}
    while time.time() < end:
        ensure_not_stopped()
        now = time.time()
        for p in d.iterdir():
            if not p.is_file() or p.name.lower().endswith(_TEMP_SUFFIXES):
                continue
            if name_contains.lower() not in p.name.lower() or now - p.stat().st_mtime > max_age_s:
                continue
            size = p.stat().st_size
            if size > 0 and last_seen.get(p) == size:       # size stable across two polls => finished
                return ok(exists=True, verified=True, **_info(p))
            last_seen[p] = size
        time.sleep(1.0)
    return fail(f"No finished file matching '{name_contains}' appeared in {d} within {timeout_s}s.",
                hint="Check the browser/app for a failed download, retry the download, or look in another folder.")


@safe_tool
def create_directory(path: str) -> dict:
    """Create a folder (and parents) if it does not exist, then verify it.

    Args:
        path: Folder to create.
    """
    d = resolve_path(path)
    d.mkdir(parents=True, exist_ok=True)
    return ok(path=str(d), verified=d.is_dir())


@safe_tool
def rename_file(path: str, new_name: str) -> dict:
    """Rename a file or folder in place (never overwrites) and verify the result.

    Args:
        path: Existing file/folder path.
        new_name: New NAME only (no folders), e.g. 'invoice_final.pdf'.
    """
    src = resolve_path(path, must_exist=True)
    if os.sep in new_name or "/" in new_name or "\\" in new_name or not new_name.strip():
        return fail("new_name must be a plain file name without folders.", hint="Use move_file to change folders.")
    dst = src.with_name(new_name.strip())
    if dst.exists():
        return fail(f"'{dst.name}' already exists in that folder.", hint="Pick a different name; nothing was changed.")
    src.rename(dst)
    verified = dst.exists() and not src.exists()
    return ok(old_path=str(src), new_path=str(dst), verified=verified)


@safe_tool
def move_file(source: str, destination_dir: str, new_name: str = "") -> dict:
    """Move a file/folder into another folder (created if missing), optionally renaming it, and verify.

    Args:
        source: Existing file/folder path.
        destination_dir: Target folder.
        new_name: Optional new file name to use at the destination.
    """
    src = resolve_path(source, must_exist=True)
    dest_dir = resolve_path(destination_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    final = dest_dir / (new_name.strip() or src.name)
    if final.exists():
        return fail(f"'{final}' already exists.", hint="Choose another new_name; nothing was moved.")
    shutil.move(str(src), str(final))
    verified = final.exists() and not src.exists()
    return ok(old_path=str(src), new_path=str(final), verified=verified)


@safe_tool
def read_text_file(path: str, max_chars: int = 4000) -> dict:
    """Read a UTF-8 text file (also usable as a verification step after writing).

    Args:
        path: File to read.
        max_chars: Maximum characters to return.
    """
    p = resolve_path(path, must_exist=True)
    text = p.read_text(encoding="utf-8", errors="replace")
    return ok(path=str(p), length=len(text), content=text[:max_chars], truncated=len(text) > max_chars)


@safe_tool
def write_text_file(path: str, content: str, append: bool = False) -> dict:
    """Save text (e.g. information found on a website) to a .txt/.md/.csv file and verify by reading it back.

    Args:
        path: Target file path (parent folders are created).
        content: Text to write.
        append: Append instead of overwrite.
    """
    p = resolve_path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    mode = "a" if append else "w"
    with open(p, mode, encoding="utf-8") as fh:
        fh.write(content)
    back = p.read_text(encoding="utf-8", errors="replace")
    verified = p.exists() and (back.endswith(content) if append else back == content)
    return ok(path=str(p), size_bytes=p.stat().st_size, verified=verified)
