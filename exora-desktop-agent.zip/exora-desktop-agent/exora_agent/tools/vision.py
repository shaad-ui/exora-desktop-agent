"""Hand-off point between tools and the model.

ADK tool results are JSON, so a tool cannot return pixels directly. Instead, screenshot tools
park the PNG here and `before_model_callback` (callbacks.py) attaches it to the next LLM
request as an image part - that is how the agent genuinely *sees* the screen.
"""
import threading
from typing import Optional

_lock = threading.Lock()
_pending: Optional[bytes] = None
_scale = (1.0, 1.0)
_calibrated = False


def set_pending(png: bytes) -> None:
    global _pending
    with _lock:
        _pending = png


def take_pending() -> Optional[bytes]:
    global _pending
    with _lock:
        data, _pending = _pending, None
        return data


def set_scale(sx: float, sy: float) -> None:
    """Ratio screenshot-pixels -> real screen coordinates."""
    global _scale, _calibrated
    with _lock:
        _scale, _calibrated = (sx, sy), True


def get_scale() -> tuple:
    with _lock:
        return _scale


def is_calibrated() -> bool:
    with _lock:
        return _calibrated
