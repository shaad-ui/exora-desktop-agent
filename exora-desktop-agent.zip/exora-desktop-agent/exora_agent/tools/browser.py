"""Web navigation & form tools (Playwright).

Design notes
------------
* Playwright's sync API must always be used from the thread that created it, and it refuses to run
  inside an asyncio loop (ADK runs on one). So ALL browser work is executed on one dedicated worker
  thread (`_Worker`) and tools just submit jobs to it. The browser persists across tool calls/tasks.
* Observation is DOM-based: `browser_get_page_state` tags every visible interactive element with a
  `data-exora-id` so the model can act with the short selector `id:12` instead of guessing CSS.
* Recovery lives inside the tools: click falls back normal -> scroll+force -> JS click; navigation
  retries with backoff and tolerates slow pages; dialogs and new tabs are handled automatically;
  a crashed browser is relaunched on the next call.
* Submission safety is ENFORCED HERE: clicking a submit-like control (or pressing Enter inside a form
  field) is blocked unless the human approved via request_user_approval (ApprovalGate grant).
"""
import concurrent.futures
import queue
import re
import sys
import threading
import time
from pathlib import Path
from typing import Callable, Optional
from urllib.parse import unquote, urlparse

from . import vision
from .common import fail, ok, resolve_path, retry, safe_tool, unique_path
from ..config import (MODEL_VISION, BROWSER_ACTION_TIMEOUT_MS, BROWSER_CHANNEL, BROWSER_HEADLESS,
                      BROWSER_NAV_TIMEOUT_MS, DOWNLOAD_DIR, SCREENSHOT_DIR)
from ..tracking import APPROVAL, TRACKER

# ----------------------------------------------------------------- browser worker
class _Worker:
    def __init__(self) -> None:
        self._q: "queue.Queue" = queue.Queue()
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self.pw = self.browser = self.context = self.page = None
        self._hooked: set = set()
        self.notes: list = []          # popups / dialogs / new tabs seen since last observation

    # -- thread plumbing -----------------------------------------------------
    def _ensure_thread(self) -> None:
        with self._lock:
            if self._thread is None or not self._thread.is_alive():
                self._thread = threading.Thread(target=self._loop, name="playwright-worker", daemon=True)
                self._thread.start()

    def _loop(self) -> None:
        while True:
            item = self._q.get()
            if item is None:
                return
            fn, fut = item
            if not fut.set_running_or_notify_cancel():
                continue
            try:
                fut.set_result(fn())
            except BaseException as exc:  # noqa: BLE001 - forwarded to caller
                fut.set_exception(exc)

    def run(self, fn: Callable, timeout: float = 150):
        self._ensure_thread()
        fut: concurrent.futures.Future = concurrent.futures.Future()
        self._q.put((fn, fut))
        return fut.result(timeout=timeout)

    # -- everything below runs ON the worker thread ----------------------------
    def _launch(self) -> None:
        from playwright.sync_api import sync_playwright
        self._teardown()
        self.pw = sync_playwright().start()
        kwargs = {"headless": BROWSER_HEADLESS}
        try:
            if BROWSER_CHANNEL:
                self.browser = self.pw.chromium.launch(channel=BROWSER_CHANNEL, **kwargs)
            else:
                self.browser = self.pw.chromium.launch(**kwargs)
        except Exception as exc:  # noqa: BLE001 - e.g. Chrome not installed -> bundled Chromium
            TRACKER.log("info", f"Browser channel '{BROWSER_CHANNEL}' unavailable ({type(exc).__name__}); using bundled Chromium.")
            self.browser = self.pw.chromium.launch(**kwargs)
        self.context = self.browser.new_context(accept_downloads=True, viewport={"width": 1366, "height": 768})
        self.context.set_default_timeout(BROWSER_ACTION_TIMEOUT_MS)
        self.context.set_default_navigation_timeout(BROWSER_NAV_TIMEOUT_MS)
        self.context.on("page", self._on_new_page)
        self.context.new_page()                      # -> _on_new_page sets self.page

    def _teardown(self) -> None:
        for obj, meth in ((self.context, "close"), (self.browser, "close"), (self.pw, "stop")):
            try:
                if obj is not None:
                    getattr(obj, meth)()
            except Exception:  # noqa: BLE001
                pass
        self.pw = self.browser = self.context = self.page = None
        self._hooked.clear()

    def _on_new_page(self, page) -> None:
        if page not in self._hooked:
            self._hooked.add(page)
            page.on("dialog", self._on_dialog)
        if self.page is not None and page is not self.page:
            self.notes.append("A new tab/popup opened; switched to it.")
        self.page = page

    def _on_dialog(self, dialog) -> None:
        # alert/beforeunload are harmless -> accept. confirm/prompt may authorise something -> dismiss & tell the agent.
        harmless = dialog.type in ("alert", "beforeunload")
        self.notes.append(f"JS {dialog.type} dialog {'accepted' if harmless else 'dismissed'}: {dialog.message[:120]}")
        try:
            dialog.accept() if harmless else dialog.dismiss()
        except Exception:  # noqa: BLE001
            pass

    def get_page(self):
        if self.browser is None or not self.browser.is_connected():
            self._launch()                           # first use, or crash recovery
        if self.page is None or self.page.is_closed():
            open_pages = [p for p in self.context.pages if not p.is_closed()]
            if open_pages:
                self.page = open_pages[-1]
            else:
                self.context.new_page()
        return self.page

    def drain_notes(self) -> list:
        notes, self.notes = self.notes, []
        return notes


_W = _Worker()


def _job(fn: Callable, timeout: float = 150):
    """Run fn(page) on the browser thread."""
    return _W.run(lambda: fn(_W.get_page()), timeout)


# --------------------------------------------------------------------- helpers
def _sel(selector: str) -> str:
    """'12' or 'id:12' -> the data-exora-id selector; anything else is passed to Playwright as is."""
    s = selector.strip()
    m = re.fullmatch(r"(?:id\s*[:=]\s*)?(\d+)", s, flags=re.I)
    return f'[data-exora-id="{m.group(1)}"]' if m else s


_STATE_JS = r"""
() => {
  const vis = el => { const r = el.getBoundingClientRect(); const s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none'; };
  document.querySelectorAll('[data-exora-id]').forEach(e => e.removeAttribute('data-exora-id'));
  const sel = 'a[href],button,input,select,textarea,summary,[role=button],[role=link],[role=checkbox],[role=tab],[onclick]';
  const out = []; let i = 0;
  for (const el of document.querySelectorAll(sel)) {
    if (!vis(el)) continue;
    const id = ++i; el.setAttribute('data-exora-id', String(id));
    const type = (el.getAttribute('type') || '').toLowerCase();
    const label = (el.labels && el.labels[0] && el.labels[0].innerText) || el.getAttribute('aria-label') || '';
    out.push({ id, tag: el.tagName.toLowerCase(), type, name: el.getAttribute('name') || '',
      text: (el.innerText || el.value || '').trim().slice(0, 60), label: label.trim().slice(0, 50),
      placeholder: el.getAttribute('placeholder') || '', href: (el.getAttribute('href') || '').slice(0, 80),
      value: type === 'password' ? '' : String(el.value || '').slice(0, 40),
      disabled: !!el.disabled, checked: !!el.checked, inForm: !!el.closest('form') });
    if (out.length >= 80) break;
  }
  const dialogs = [...document.querySelectorAll('[role=dialog],[aria-modal=true],.modal.show,.modal[open],dialog[open]')]
    .filter(vis).map(d => (d.innerText || '').trim().slice(0, 160));
  return { elements: out, dialogs };
}
"""

_SUBMIT_JS = r"""
el => { const tag = el.tagName.toLowerCase(); const t = (el.getAttribute('type') || '').toLowerCase();
  const txt = (el.innerText || el.value || '').toLowerCase(); const inForm = !!el.closest('form');
  if (tag === 'input' && (t === 'submit' || t === 'image')) return true;
  if (tag === 'button' && inForm && (t === '' || t === 'submit')) return true;
  return inForm && /\b(submit|send|place order|pay now|purchase|confirm|register|sign up|apply|checkout)\b/.test(txt); }
"""


def _submit_blocked(page, selector: str) -> Optional[dict]:
    """Return a failure dict if `selector` would submit a form without human approval."""
    try:
        risky = page.locator(selector).first.evaluate(_SUBMIT_JS, timeout=3000)
    except Exception:  # noqa: BLE001 - selector problems are reported by the click itself
        return None
    if risky and not APPROVAL.grant_available():
        return fail("BLOCKED: this control submits a form and the user has not approved it yet.",
                    hint="Fill every field, call request_user_approval(summary, field_values), and only click "
                         "submit after it returns approved=True.", requires_approval=True)
    return None


def _click_with_fallbacks(page, selector: str, timeout_s: int) -> str:
    """Try progressively more forceful clicks; return the strategy that worked."""
    loc = page.locator(selector).first
    last: Optional[Exception] = None
    for name, action in (
        ("normal", lambda: loc.click(timeout=timeout_s * 1000)),
        ("scroll+force", lambda: (loc.scroll_into_view_if_needed(timeout=3000), loc.click(force=True, timeout=3000))),
        ("js-click", lambda: loc.evaluate("el => el.click()", timeout=3000)),
    ):
        try:
            action()
            return name
        except Exception as exc:  # noqa: BLE001
            last = exc
            time.sleep(0.5)
    assert last is not None
    raise last


def _settle(page) -> None:
    for state in ("domcontentloaded", "load"):
        try:
            page.wait_for_load_state(state, timeout=6000)
        except Exception:  # noqa: BLE001 - slow page: continue with whatever has loaded
            return


def _filename_from(url: str, fallback: str = "download") -> str:
    name = Path(unquote(urlparse(url).path)).name
    return name or fallback


# ------------------------------------------------------------------- navigation
@safe_tool
def browser_open_url(url: str) -> dict:
    """Open a web page in the automated browser (starts the browser on first use). Retries slow loads.

    Args:
        url: Full URL; 'https://' is added if missing.
    """
    if not re.match(r"^https?://", url, flags=re.I):
        url = "https://" + url
    if not re.match(r"^https?://[^\s]+$", url, flags=re.I):
        return fail("Invalid URL.")

    def job(page):
        def go():
            resp = page.goto(url, wait_until="domcontentloaded", timeout=BROWSER_NAV_TIMEOUT_MS)
            return resp.status if resp else None
        status = retry(go, attempts=3, delay=2.0)       # slow / flaky servers
        loaded = True
        try:
            page.wait_for_load_state("load", timeout=10000)
        except Exception:  # noqa: BLE001
            loaded = False                              # still usable; note it for the model
        return ok(url=page.url, title=page.title(), http_status=status, fully_loaded=loaded,
                  notes=_W.drain_notes(), next="Call browser_get_page_state to see the elements.")
    return _job(job)


@safe_tool
def browser_get_page_state(max_text_chars: int = 2500) -> dict:
    """OBSERVE the web page: URL, title, visible text, popups/dialogs and a numbered list of interactive
    elements. Act on an element with its number, e.g. browser_click('12') or browser_fill('7','text').
    Numbers are re-assigned on every call, so call this again after the page changes.

    Args:
        max_text_chars: How much visible page text to include.
    """
    def job(page):
        _settle(page)
        data = page.evaluate(_STATE_JS)
        try:
            text = page.inner_text("body", timeout=3000)
        except Exception:  # noqa: BLE001
            text = ""
        lines = []
        for e in data["elements"]:
            bits = [f"[{e['id']}] <{e['tag']}{'/' + e['type'] if e['type'] else ''}>"]
            for key in ("text", "label", "name", "placeholder", "href", "value"):
                if e[key]:
                    bits.append(f"{key}='{e[key]}'")
            if e["disabled"]:
                bits.append("DISABLED")
            if e["checked"]:
                bits.append("CHECKED")
            if e["inForm"]:
                bits.append("in-form")
            lines.append(" ".join(bits))
        return ok(url=page.url, title=page.title(), tabs=len(_W.context.pages),
                  popups_or_dialogs=data["dialogs"], notes=_W.drain_notes(),
                  visible_text=re.sub(r"\n{3,}", "\n\n", text)[:max_text_chars], elements=lines,
                  hint="If popups_or_dialogs is non-empty, call browser_dismiss_popups first.")
    return _job(job)


@safe_tool
def browser_click(selector: str, timeout_s: int = 10) -> dict:
    """Click a link/button/element. Retries with stronger strategies if the first click does not work.
    Submit buttons are BLOCKED until the user approved through request_user_approval.

    Args:
        selector: Element number from browser_get_page_state (e.g. '12'), or a CSS / 'text=Download' selector.
        timeout_s: Seconds to wait for the element.
    """
    sel = _sel(selector)

    def job(page):
        blocked = _submit_blocked(page, sel)
        if blocked:
            return blocked
        risky_click = APPROVAL.grant_available()
        before, tabs_before = page.url, len(_W.context.pages)
        strategy = _click_with_fallbacks(page, sel, timeout_s)
        if risky_click:
            APPROVAL.consume_grant()                    # one approval = one submission
        _settle(_W.get_page())
        now = _W.get_page()
        return ok(clicked=selector, strategy=strategy, url_before=before, url_after=now.url,
                  navigated=now.url != before, new_tab=len(_W.context.pages) > tabs_before,
                  notes=_W.drain_notes(), next="Call browser_get_page_state to verify the result.")
    return _job(job)


@safe_tool
def browser_fill(selector: str, value: str) -> dict:
    """Type a value into a text input/textarea (replaces existing text) and verify what the field now contains.

    Args:
        selector: Element number from browser_get_page_state or a CSS selector.
        value: Text to enter.
    """
    sel = _sel(selector)

    def job(page):
        loc = page.locator(sel).first
        try:
            retry(lambda: loc.fill(value, timeout=8000), attempts=2, delay=0.5)
        except Exception:  # noqa: BLE001 - fallback: focus + select-all + keystrokes
            loc.click(timeout=3000)
            page.keyboard.press("Meta+A" if sys.platform == "darwin" else "Control+A")
            page.keyboard.type(value, delay=20)
        actual = loc.input_value(timeout=3000)
        is_pwd = (loc.get_attribute("type") or "").lower() == "password"
        return ok(filled=selector, verified=actual == value,
                  field_now=("<hidden>" if is_pwd else actual[:80]), notes=_W.drain_notes())
    return _job(job)


@safe_tool
def browser_select_option(selector: str, option: str) -> dict:
    """Choose an option in a <select> dropdown by its visible label (falls back to its value) and verify.

    Args:
        selector: Element number or CSS selector of the dropdown.
        option: Visible text (or value) of the option.
    """
    sel = _sel(selector)

    def job(page):
        loc = page.locator(sel).first
        try:
            loc.select_option(label=option, timeout=5000)
        except Exception:  # noqa: BLE001
            loc.select_option(value=option, timeout=5000)
        chosen = loc.evaluate("el => el.options[el.selectedIndex] ? el.options[el.selectedIndex].text : ''")
        value = loc.input_value()
        return ok(selected=chosen, verified=option.lower() in (chosen.lower(), value.lower()))
    return _job(job)


@safe_tool
def browser_set_checkbox(selector: str, checked: bool = True) -> dict:
    """Tick or untick a checkbox / radio button and verify the state.

    Args:
        selector: Element number or CSS selector.
        checked: Desired state.
    """
    sel = _sel(selector)

    def job(page):
        loc = page.locator(sel).first
        loc.set_checked(checked, timeout=6000)
        return ok(checked=loc.is_checked(), verified=loc.is_checked() == checked)
    return _job(job)


@safe_tool
def browser_press_key(key: str) -> dict:
    """Press a key in the page, e.g. 'Tab', 'Escape', 'PageDown'. 'Enter' inside a form field is blocked
    until the user approved (it would submit the form).

    Args:
        key: Playwright key name.
    """
    def job(page):
        if key.lower() in ("enter", "return"):
            in_form = page.evaluate("() => { const a = document.activeElement; "
                                    "return !!(a && a.closest && a.closest('form') && a.tagName !== 'TEXTAREA'); }")
            if in_form and not APPROVAL.grant_available():
                return fail("BLOCKED: Enter in a form field would submit it without user approval.",
                            hint="Use request_user_approval first, or click the intended non-submit control.",
                            requires_approval=True)
        page.keyboard.press(key)
        return ok(pressed=key, notes=_W.drain_notes())
    return _job(job)


@safe_tool
def browser_scroll(direction: str = "down", amount: int = 600) -> dict:
    """Scroll the page to reveal more content.

    Args:
        direction: 'down', 'up', 'top' or 'bottom'.
        amount: Pixels for up/down.
    """
    def job(page):
        d = direction.lower()
        if d == "top":
            page.evaluate("window.scrollTo(0, 0)")
        elif d == "bottom":
            page.evaluate("window.scrollTo(0, document.body.scrollHeight)")
        else:
            page.mouse.wheel(0, amount if d == "down" else -amount)
        page.wait_for_timeout(300)
        return ok(scroll_y=page.evaluate("Math.round(window.scrollY)"),
                  page_height=page.evaluate("document.body.scrollHeight"))
    return _job(job)


@safe_tool
def browser_wait_for(target: str, kind: str = "text", timeout_s: int = 15) -> dict:
    """Wait for something to appear - use for slow pages instead of repeating actions.

    Args:
        target: The text, CSS selector or URL fragment to wait for.
        kind: 'text', 'selector' or 'url_contains'.
        timeout_s: Seconds to wait.
    """
    def job(page):
        ms = max(1, timeout_s) * 1000
        if kind == "selector":
            page.locator(_sel(target)).first.wait_for(state="visible", timeout=ms)
        elif kind == "url_contains":
            page.wait_for_url(lambda u: target in u, timeout=ms)
        else:
            page.get_by_text(target, exact=False).first.wait_for(state="visible", timeout=ms)
        return ok(found=target, url=page.url)
    return _job(job, timeout=timeout_s + 60)


@safe_tool
def browser_dismiss_popups() -> dict:
    """Try to close cookie banners, modals and overlays that block the page (Escape + common close buttons)."""
    candidates = [
        '[aria-label="Close" i]', '[aria-label="Dismiss" i]', 'button:has-text("Accept all")',
        'button:has-text("Accept")', 'button:has-text("I agree")', 'button:has-text("Got it")',
        'button:has-text("No thanks")', 'button:has-text("Not now")', 'button:has-text("Close")',
        'button:has-text("Dismiss")', '.modal.show .btn-close', '.modal.show button.close', 'button:has-text("×")',
    ]

    def job(page):
        closed = []
        page.keyboard.press("Escape")
        for css in candidates:
            try:
                loc = page.locator(css).first
                if loc.is_visible(timeout=400):
                    if _submit_blocked(page, css):     # never dismiss by clicking a form-submit control
                        continue
                    loc.click(timeout=2000)
                    closed.append(css)
                    page.wait_for_timeout(300)
            except Exception:  # noqa: BLE001
                continue
        return ok(dismissed=closed, notes=_W.drain_notes(), next="Call browser_get_page_state to confirm the page is clear.")
    return _job(job)


@safe_tool
def browser_go_back() -> dict:
    """Go back one page in history (recover from wrong navigation)."""
    def job(page):
        page.go_back(wait_until="domcontentloaded", timeout=BROWSER_NAV_TIMEOUT_MS)
        return ok(url=page.url, title=page.title())
    return _job(job)


@safe_tool
def browser_list_tabs() -> dict:
    """List open browser tabs with their index, title and URL."""
    def job(page):
        return ok(tabs=[{"index": i, "title": p.title(), "url": p.url} for i, p in enumerate(_W.context.pages)],
                  active=_W.context.pages.index(page) if page in _W.context.pages else -1)
    return _job(job)


@safe_tool
def browser_switch_tab(index: int) -> dict:
    """Switch to another tab by index (see browser_list_tabs).

    Args:
        index: Tab index.
    """
    def job(page):
        pages = _W.context.pages
        if not 0 <= index < len(pages):
            return fail(f"No tab {index}; there are {len(pages)} tabs.")
        _W.page = pages[index]
        _W.page.bring_to_front()
        return ok(url=_W.page.url, title=_W.page.title())
    return _job(job)


@safe_tool
def browser_screenshot(full_page: bool = False) -> dict:
    """Take a screenshot of the web page; you will see it on your next turn (useful for visual checks).

    Args:
        full_page: Capture the whole scrollable page.
    """
    if not MODEL_VISION:
        return fail("Screenshots are unavailable: the current model cannot see images.",
                    hint="Use browser_get_page_state / browser_extract_text / browser_verify instead.")

    def job(page):
        png = page.screenshot(full_page=full_page)
        SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)
        path = SCREENSHOT_DIR / f"page_{time.strftime('%H%M%S')}_{int(time.time()*1000) % 1000}.png"
        path.write_bytes(png)
        vision.set_pending(png)
        TRACKER.set_screenshot(str(path))
        return ok(screenshot_path=str(path), url=page.url, note="Screenshot attached to your next message.")
    return _job(job)


@safe_tool
def browser_close() -> dict:
    """Close the automated browser (it restarts automatically on the next browser_open_url)."""
    _W.run(_W._teardown)
    return ok(closed=True)


# ------------------------------------------------------------------- extraction
@safe_tool
def browser_extract_text(selector: str = "body", max_chars: int = 4000) -> dict:
    """Extract the visible text of an element/page (to read information or save it to a document).

    Args:
        selector: Element number or CSS selector; default is the whole page.
        max_chars: Maximum characters to return.
    """
    sel = _sel(selector)

    def job(page):
        text = page.locator(sel).first.inner_text(timeout=8000)
        return ok(selector=selector, length=len(text), text=text[:max_chars], truncated=len(text) > max_chars)
    return _job(job)


@safe_tool
def browser_extract_links(contains: str = "", max_links: int = 40) -> dict:
    """List links on the page (text + absolute URL), optionally filtered - handy for finding download links.

    Args:
        contains: Keep only links whose text or URL contains this (case-insensitive).
        max_links: Maximum links to return.
    """
    def job(page):
        links = page.evaluate("() => [...document.querySelectorAll('a[href]')].map(a => ({text: (a.innerText||'').trim().slice(0,80), url: a.href}))")
        needle = contains.lower()
        links = [l for l in links if not needle or needle in l["text"].lower() or needle in l["url"].lower()]
        return ok(count=len(links), links=links[:max_links])
    return _job(job)


@safe_tool
def browser_extract_table(selector: str = "table", max_rows: int = 40) -> dict:
    """Extract an HTML table as rows of cell text.

    Args:
        selector: CSS selector of the table.
        max_rows: Maximum rows to return.
    """
    def job(page):
        rows = page.locator(selector).first.evaluate(
            "t => [...t.rows].map(r => [...r.cells].map(c => c.innerText.trim()))", timeout=8000)
        return ok(total_rows=len(rows), rows=rows[:max_rows])
    return _job(job)


@safe_tool
def browser_verify(expected_text: str = "", url_contains: str = "", selector: str = "") -> dict:
    """VERIFICATION TOOL: assert the page state - text visible, URL contains something, element present.

    Args:
        expected_text: Text that must appear on the page (case-insensitive).
        url_contains: Fragment the current URL must contain.
        selector: Element that must be present.
    """
    def job(page):
        checks = {}
        if expected_text:
            checks["text_present"] = expected_text.lower() in page.inner_text("body", timeout=5000).lower()
        if url_contains:
            checks["url_matches"] = url_contains in page.url
        if selector:
            checks["element_present"] = page.locator(_sel(selector)).count() > 0
        good = bool(checks) and all(checks.values())
        out = {"status": "success", "verified": good, "checks": checks, "url": page.url}
        if not good:
            out["hint"] = "Expectation not met. Observe the page again; the action may have failed or needs more time."
        return out
    return _job(job)


# ---------------------------------------------------------------------- downloads
@safe_tool
def browser_download_via_click(selector: str, save_dir: str = "", filename: str = "") -> dict:
    """Click a download link/button, capture the download, save it to a folder and VERIFY it exists on disk.

    Args:
        selector: Element number or selector of the download control.
        save_dir: Target folder (default: the configured download folder).
        filename: Optional file name; default is the name suggested by the site.
    """
    sel = _sel(selector)
    dest_dir = resolve_path(save_dir) if save_dir.strip() else DOWNLOAD_DIR
    dest_dir.mkdir(parents=True, exist_ok=True)

    def job(page):
        blocked = _submit_blocked(page, sel)
        if blocked:
            return blocked
        with page.expect_download(timeout=45000) as info:
            _click_with_fallbacks(page, sel, 10)
        dl = info.value
        problem = dl.failure()
        if problem:
            return fail(f"Download failed: {problem}", hint="Retry once; otherwise try browser_download_url with the link URL.")
        target = unique_path(dest_dir / (filename.strip() or dl.suggested_filename))
        dl.save_as(str(target))
        size = target.stat().st_size if target.exists() else 0
        return ok(saved_to=str(target), size_bytes=size, source_url=dl.url, verified=target.exists() and size > 0)
    return _job(job, timeout=200)


@safe_tool
def browser_download_url(url: str, save_dir: str = "", filename: str = "") -> dict:
    """Download a file directly from a URL (uses the browser session's cookies) and VERIFY it on disk.
    Good fallback when clicking a download link does not trigger a download.

    Args:
        url: Direct file URL (get it from browser_extract_links).
        save_dir: Target folder (default: the configured download folder).
        filename: Optional file name; default is taken from the URL.
    """
    dest_dir = resolve_path(save_dir) if save_dir.strip() else DOWNLOAD_DIR
    dest_dir.mkdir(parents=True, exist_ok=True)

    def job(page):
        resp = retry(lambda: page.context.request.get(url, timeout=60000), attempts=3, delay=2.0)
        if not resp.ok:
            return fail(f"Server answered HTTP {resp.status} for that URL.", hint="Check the link with browser_extract_links.")
        target = unique_path(dest_dir / (filename.strip() or _filename_from(resp.url or url)))
        target.write_bytes(resp.body())
        size = target.stat().st_size
        return ok(saved_to=str(target), size_bytes=size, http_status=resp.status, verified=target.exists() and size > 0)
    return _job(job, timeout=200)
