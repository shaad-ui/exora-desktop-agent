"""Shared helpers for every tool: result envelope, safe wrapper, retry, path sandbox.

NOTE: tool modules deliberately avoid `from __future__ import annotations` - ADK builds the
Gemini function schema from the real type hints of each function.
"""
import functools
import inspect
import os
import time
from pathlib import Path
from typing import Callable, Optional

from ..config import ALLOWED_ROOTS
from ..tracking import TaskStopped, ensure_not_stopped


# ------------------------------------------------------------------ result envelope
def ok(**data) -> dict:
    """Uniform success result. Always contains status='success'."""
    return {"status": "success", **data}


def fail(error: str, hint: str = "", **data) -> dict:
    """Uniform failure result. The `hint` tells the model what recovery to try next."""
    out = {"status": "error", "error": error}
    if hint:
        out["hint"] = hint
    out.update(data)
    return out


# ------------------------------------------------------------------- error triage
def _triage(exc: BaseException) -> str:
    """Map an exception to an actionable recovery hint for the LLM."""
    name = type(exc).__name__
    text = str(exc).lower()
    if name == "TimeoutError" or "timeout" in text:
        return ("Element or page was not ready in time. Try browser_wait_for, then "
                "browser_get_page_state to re-read the page, dismiss popups, or use a different selector.")
    if isinstance(exc, FileNotFoundError):
        return "Path does not exist. Use search_files / list_directory to locate the real path."
    if isinstance(exc, PermissionError):
        return ("Permission denied: the file may be open/locked in another program (close it) "
                "or the path is outside the allowed folders.")
    if name == "FailSafeException":
        return "PyAutoGUI fail-safe triggered (mouse in a screen corner). Move on and retry the action."
    if isinstance(exc, ImportError):
        return "A required Python package is missing - tell the user which one to install."
    if "target page, context or browser has been closed" in text or "browser has been closed" in text:
        return "The browser/tab was closed. Call browser_open_url again; a fresh browser will be started."
    if "strict mode violation" in text:
        return "Selector matched several elements. Use a more specific selector or an id from browser_get_page_state."
    return "Unexpected error. Observe the current state again and try an alternative approach."


def safe_tool(fn: Callable) -> Callable:
    """Decorator: a tool NEVER raises into the agent loop.

    Exceptions become structured error results with a recovery hint, so the model can retry,
    pick a fallback, or re-plan instead of the whole run crashing. `functools.wraps` keeps the
    original signature/docstring, which ADK uses to generate the tool schema.
    """
    name = fn.__name__

    if inspect.iscoroutinefunction(fn):
        @functools.wraps(fn)
        async def awrapper(*args, **kwargs):
            try:
                ensure_not_stopped()
                return await fn(*args, **kwargs)
            except TaskStopped as exc:
                return fail(str(exc), stopped=True)
            except Exception as exc:  # noqa: BLE001 - deliberate catch-all at the tool boundary
                return fail(f"{type(exc).__name__}: {exc}"[:600], hint=_triage(exc), tool=name)
        return awrapper

    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            ensure_not_stopped()
            return fn(*args, **kwargs)
        except TaskStopped as exc:
            return fail(str(exc), stopped=True)
        except Exception as exc:  # noqa: BLE001
            return fail(f"{type(exc).__name__}: {exc}"[:600], hint=_triage(exc), tool=name)
    return wrapper


# ------------------------------------------------------------------------- retry
def retry(fn: Callable, attempts: int = 3, delay: float = 1.0, backoff: float = 2.0,
          exceptions: tuple = (Exception,)):
    """Call fn() up to `attempts` times with exponential backoff; re-raise the last error."""
    last: Optional[BaseException] = None
    for i in range(attempts):
        ensure_not_stopped()
        try:
            return fn()
        except TaskStopped:
            raise
        except exceptions as exc:  # noqa: PERF203
            last = exc
            if i < attempts - 1:
                time.sleep(delay * (backoff ** i))
    assert last is not None
    raise last


# -------------------------------------------------------------------- path sandbox
def _within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def resolve_path(p: str, must_exist: bool = False) -> Path:
    """Expand ~ and env vars, treat relative paths as relative to the home folder, and enforce
    that the result lives under one of EXORA_ALLOWED_ROOTS (safety sandbox)."""
    if not p or not str(p).strip():
        raise ValueError("Path is empty.")
    raw = os.path.expandvars(os.path.expanduser(str(p).strip()))
    path = Path(raw)
    if not path.is_absolute():
        path = Path.home() / path
    path = path.resolve()
    if not any(_within(path, root) for root in ALLOWED_ROOTS):
        roots = ", ".join(str(r) for r in ALLOWED_ROOTS)
        raise PermissionError(f"'{path}' is outside the allowed folders ({roots}).")
    if must_exist and not path.exists():
        raise FileNotFoundError(f"'{path}' does not exist.")
    return path


def unique_path(path: Path) -> Path:
    """Return path, or 'name (1).ext' etc. if it already exists (never overwrite silently)."""
    if not path.exists():
        return path
    for i in range(1, 1000):
        cand = path.with_name(f"{path.stem} ({i}){path.suffix}")
        if not cand.exists():
            return cand
    raise FileExistsError(f"Could not find a free name for {path}")
