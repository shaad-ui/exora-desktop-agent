"""The ADK agent definition.

`root_agent` is the module-level name ADK tooling (`adk web`, `adk run`) looks for, so the same agent
works in the Streamlit UI, the CLI and the ADK dev UI.
"""
from google.adk.agents import Agent
from google.genai import types

from .callbacks import after_tool, before_model, before_tool
from .config import MODEL, MODEL_VISION
from .prompts import SYSTEM_INSTRUCTION, TEXT_ONLY_NOTE
from .tools import ALL_TOOLS

def _build_model():
    """Gemini names go straight to ADK; everything else (Groq, OpenAI, Ollama...) goes through LiteLLM."""
    if MODEL.startswith("gemini"):
        return MODEL
    from .llm_sanitizer import make_litellm
    # num_retries: back off on 429 rate limits; drop_params: ignore options a provider does not support.
    # make_litellm adds the strict message sanitiser (strips reasoning_content etc.) on the wire.
    return make_litellm(MODEL, num_retries=5, drop_params=True)


# Tools that need eyes. Removing them in text-only mode saves tokens and avoids pointless calls.
_TEXT_ONLY_DROP = {"observe_screen", "click", "scroll", "browser_screenshot", "browser_list_tabs",
                   "browser_switch_tab", "browser_close", "browser_extract_table", "create_directory"}
_TOOLS = ALL_TOOLS if MODEL_VISION else [t for t in ALL_TOOLS if t.__name__ not in _TEXT_ONLY_DROP]

root_agent = Agent(
    name="exora_desktop_agent",
    model=_build_model(),
    description="Autonomous agent that operates the desktop, browser, files and spreadsheets from plain-English tasks.",
    instruction=SYSTEM_INSTRUCTION + ('' if MODEL_VISION else TEXT_ONLY_NOTE),
    tools=_TOOLS,                       # plain functions -> ADK wraps each as a FunctionTool
    before_model_callback=before_model,
    before_tool_callback=before_tool,
    after_tool_callback=after_tool,
    generate_content_config=types.GenerateContentConfig(temperature=0.1),   # low temperature = reliable tool use
)
