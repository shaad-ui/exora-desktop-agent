"""Strict message sanitising for OpenAI-compatible providers (Groq, etc.).

Why this exists
---------------
When a reasoning-capable model answers, ADK stores its "thinking" as `thought` parts. On the NEXT request
ADK's LiteLLM adapter converts those parts into a non-standard `reasoning_content` field on the assistant
message. Groq's API validates the schema strictly and rejects it:
    'messages.2': for 'role:assistant' ... property 'reasoning_content' is unsupported

Two layers of defence (use both; they are independent):
  1. strip_thought_parts()      - removes thought parts from the ADK request BEFORE conversion (callbacks.py)
  2. sanitize_messages()        - whitelists fields on the final OpenAI-style message list, in a client wrapper
                                  that sits right on the wire (SanitizingLiteLLMClient)
"""
import json
import logging
from typing import Any

from google.adk.models.lite_llm import LiteLLMClient, LiteLlm

log = logging.getLogger("exora.sanitizer")

# Fields each role may carry in the OpenAI-compatible chat schema. Everything else is dropped.
ALLOWED_FIELDS = {
    "system": {"role", "content", "name"},
    "developer": {"role", "content", "name"},
    "user": {"role", "content", "name"},
    "assistant": {"role", "content", "name", "tool_calls"},
    "tool": {"role", "content", "tool_call_id", "name"},
}
_reported: set = set()


def _as_dict(msg: Any) -> dict:
    if isinstance(msg, dict):
        return dict(msg)
    if hasattr(msg, "model_dump"):
        return msg.model_dump(exclude_none=False)
    return dict(msg)


def _flatten_text(content: Any) -> Any:
    """Providers like Groq want a plain string for system/assistant/tool content, not a list of parts."""
    if isinstance(content, list):
        if all(isinstance(p, dict) and p.get("type") == "text" for p in content):
            return "\n".join(str(p.get("text", "")) for p in content)
        return content                       # mixed (e.g. images) - leave untouched
    return content


def _clean_tool_calls(calls: Any) -> list:
    cleaned = []
    for call in calls or []:
        call = _as_dict(call)
        fn = _as_dict(call.get("function") or {})
        args = fn.get("arguments", "{}")
        if not isinstance(args, str):
            args = json.dumps(args, ensure_ascii=False, default=str)
        cleaned.append({"id": call.get("id"), "type": "function",
                        "function": {"name": fn.get("name", ""), "arguments": args or "{}"}})
    return cleaned


def sanitize_messages(messages: list) -> list:
    """Return a new message list containing only schema-valid fields. Never mutates the input."""
    out = []
    for raw in messages or []:
        msg = _as_dict(raw)
        role = msg.get("role", "user")
        role = "assistant" if role == "model" else role
        allowed = ALLOWED_FIELDS.get(role, {"role", "content", "name"})

        dropped = [k for k in msg if k not in allowed]
        for key in dropped:
            if key not in _reported:             # tell the user once, not on every call
                _reported.add(key)
                log.info("Stripped unsupported message field '%s' from %s messages", key, role)
        clean = {k: v for k, v in msg.items() if k in allowed}
        clean["role"] = role

        if role in ("system", "developer", "assistant", "tool"):
            clean["content"] = _flatten_text(clean.get("content"))
        if role == "tool" and not isinstance(clean.get("content"), str):
            clean["content"] = json.dumps(clean.get("content"), ensure_ascii=False, default=str)
        if role == "assistant":
            calls = _clean_tool_calls(clean.get("tool_calls"))
            if calls:
                clean["tool_calls"] = calls
            else:
                clean.pop("tool_calls", None)
            if not clean.get("content") and not calls:
                continue                         # an empty assistant message is invalid - drop it
            if clean.get("content") is None and calls:
                clean["content"] = ""            # some providers reject null content next to tool_calls
        out.append(clean)
    return out


def strip_thought_parts(contents: list) -> None:
    """Layer 1: remove `thought` parts from an ADK request's contents, in place."""
    kept = []
    for content in contents:
        parts = getattr(content, "parts", None) or []
        non_thought = [p for p in parts if not getattr(p, "thought", False)]
        if non_thought or not parts:
            content.parts = non_thought
            kept.append(content)
    contents[:] = kept


class SanitizingLiteLLMClient(LiteLLMClient):
    """Layer 2: sanitises the message array immediately before it goes over the wire."""

    async def acompletion(self, model, messages, tools, **kwargs):
        return await super().acompletion(model=model, messages=sanitize_messages(messages), tools=tools, **kwargs)

    def completion(self, model, messages, tools, stream=False, **kwargs):
        return super().completion(model=model, messages=sanitize_messages(messages), tools=tools,
                                  stream=stream, **kwargs)


def make_litellm(model: str, **kwargs) -> LiteLlm:
    """LiteLlm whose outgoing messages are always schema-clean."""
    llm = LiteLlm(model=model, **kwargs)
    llm.llm_client = SanitizingLiteLLMClient()
    return llm
