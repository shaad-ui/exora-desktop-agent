"""Run the offline suite against the native-Gemini code path (no network, no litellm calls)."""
import os

os.environ["EXORA_MODEL"] = "gemini-2.5-flash"
os.environ.setdefault("GOOGLE_API_KEY", "dummy")
