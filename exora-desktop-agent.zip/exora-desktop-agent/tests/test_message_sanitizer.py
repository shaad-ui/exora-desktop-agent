"""Regression tests for the Groq 'reasoning_content is unsupported' BadRequestError."""
import asyncio

from google.genai import types

from exora_agent import llm_sanitizer as san


def test_reasoning_content_is_stripped_and_tool_calls_normalised():
    msgs = [
        {"role": "system", "content": [{"type": "text", "text": "be safe"}]},
        {"role": "user", "content": "open chrome"},
        {"role": "assistant", "content": None, "reasoning_content": "thinking...", "provider_specific_fields": {"x": 1},
         "tool_calls": [{"id": "c1", "type": "function", "index": 0, "extra_content": {"g": 1},
                         "function": {"name": "set_plan", "arguments": {"steps": ["a"]}}}]},
        {"role": "tool", "tool_call_id": "c1", "content": {"status": "success"}, "extra": 1},
        {"role": "assistant", "content": "done", "reasoning": "more thinking"},
        {"role": "assistant", "content": None},                       # empty -> must be dropped
    ]
    out = san.sanitize_messages(msgs)
    assert [m["role"] for m in out] == ["system", "user", "assistant", "tool", "assistant"]
    assert out[0]["content"] == "be safe"                              # list-of-text flattened
    allowed = san.ALLOWED_FIELDS
    assert all(set(m) <= allowed[m["role"]] for m in out)
    assert "reasoning_content" not in out[2] and "reasoning" not in out[4]
    call = out[2]["tool_calls"][0]
    assert set(call) == {"id", "type", "function"} and isinstance(call["function"]["arguments"], str)
    assert out[3]["content"] == '{"status": "success"}'
    assert "reasoning_content" in msgs[2]                              # input not mutated


def test_adk_really_produces_reasoning_content_and_we_remove_it():
    """Prove the bug's root cause with ADK's own converter, then prove the fix."""
    from google.adk.models import lite_llm
    content = types.Content(role="model", parts=[
        types.Part(text="I should plan first", thought=True),
        types.Part(function_call=types.FunctionCall(name="set_plan", args={"steps": ["x"]}, id="c1")),
    ])
    raw = asyncio.run(lite_llm._content_to_message_param(content, model="groq/openai/gpt-oss-120b",
                                                         provider="groq", custom_llm_provider="groq"))
    raw = raw[0] if isinstance(raw, list) else raw
    assert "reasoning_content" in raw, "ADK no longer emits reasoning_content - re-check the root cause"
    assert "reasoning_content" not in san.sanitize_messages([raw])[0]  # layer 2

    contents = [content]                                               # layer 1
    san.strip_thought_parts(contents)
    assert len(contents[0].parts) == 1 and contents[0].parts[0].function_call


def test_strip_thought_parts_drops_thought_only_messages():
    contents = [types.Content(role="model", parts=[types.Part(text="hmm", thought=True)]),
                types.Content(role="user", parts=[types.Part(text="hi")])]
    san.strip_thought_parts(contents)
    assert len(contents) == 1 and contents[0].role == "user"


def test_client_wrapper_sanitises_on_the_wire(monkeypatch):
    from google.adk.models import lite_llm
    seen = {}

    async def fake_acompletion(**kw):
        seen.update(kw)
        return "ok"
    monkeypatch.setattr(lite_llm, "acompletion", fake_acompletion)
    res = asyncio.run(san.SanitizingLiteLLMClient().acompletion(
        model="groq/x", tools=None,
        messages=[{"role": "assistant", "content": "hi", "reasoning_content": "secret"}]))
    assert res == "ok" and "reasoning_content" not in seen["messages"][0]


def test_agent_uses_sanitising_client(monkeypatch):
    import importlib
    from exora_agent import agent
    monkeypatch.setattr(agent, "MODEL", "groq/openai/gpt-oss-120b")
    model = agent._build_model()
    assert isinstance(model.llm_client, san.SanitizingLiteLLMClient)
