"""Tests for the Groq-specific hardening: preflight key check, schema slimming, malformed-tool-call retry."""
import io
import json
import urllib.error
from pathlib import Path

import pytest


class _Resp(io.BytesIO):
    def __enter__(self): return self
    def __exit__(self, *a): return False


def _http_error(code):
    return urllib.error.HTTPError("https://api.groq.com", code, "err", {}, io.BytesIO(b"{}"))


@pytest.fixture()
def groq(monkeypatch):
    from exora_agent import preflight
    monkeypatch.setattr(preflight, "MODEL", "groq/llama-3.3-70b-versatile")
    return preflight


def test_preflight_rejects_missing_and_placeholder_keys(groq, monkeypatch):
    monkeypatch.delenv("GROQ_API_KEY", raising=False)
    ok, msg = groq.check_llm(force=True)
    assert not ok and "not set" in msg
    monkeypatch.setenv("GROQ_API_KEY", "your-groq-api-key")
    ok, msg = groq.check_llm(force=True)
    assert not ok and "gsk_" in msg


def test_preflight_invalid_key_401(groq, monkeypatch):
    monkeypatch.setenv("GROQ_API_KEY", "gsk_" + "x" * 48)
    def boom(*a, **k): raise _http_error(401)
    monkeypatch.setattr(groq.urllib.request, "urlopen", boom)
    ok, msg = groq.check_llm(force=True)
    assert not ok and "rejected" in msg and "gsk_xxxx" not in msg    # key is masked


def test_preflight_ok_and_model_check(groq, monkeypatch):
    monkeypatch.setenv("GROQ_API_KEY", "gsk_" + "x" * 48)
    body = json.dumps({"data": [{"id": "llama-3.3-70b-versatile"}, {"id": "llama-3.1-8b-instant"}]}).encode()
    monkeypatch.setattr(groq.urllib.request, "urlopen", lambda *a, **k: _Resp(body))
    ok, msg = groq.check_llm(force=True)
    assert ok and "available" in msg
    monkeypatch.setattr(groq, "MODEL", "groq/llama-typo-70b")
    ok, msg = groq.check_llm(force=True)
    assert not ok and "llama-3.3-70b-versatile" in msg               # suggests real names


def test_slimming_cuts_tool_tokens():
    from google.adk.models.llm_request import LlmRequest
    from google.adk.tools import FunctionTool
    from exora_agent.callbacks import _slim_tools
    from exora_agent.tools import ALL_TOOLS

    req = LlmRequest()
    for fn in ALL_TOOLS:
        FunctionTool(fn)._get_declaration()          # sanity
    from google.genai import types
    decls = [FunctionTool(fn)._get_declaration() for fn in ALL_TOOLS]
    req.config = types.GenerateContentConfig(tools=[types.Tool(function_declarations=decls)])
    size = lambda: len(json.dumps([d.model_dump(exclude_none=True) for d in req.config.tools[0].function_declarations], default=str))
    before = size()
    _slim_tools(req)
    after = size()
    assert after < before * 0.75, (before, after)
    names = [d.name for d in req.config.tools[0].function_declarations]
    assert "browser_click" in names and all(d.description for d in req.config.tools[0].function_declarations)
