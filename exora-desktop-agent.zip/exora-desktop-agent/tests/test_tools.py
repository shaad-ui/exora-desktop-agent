"""Offline tests for the deterministic parts: sandbox, file tools, spreadsheet tools, verification gate.
Run:  pytest -q      (no display, browser or API key needed)"""
import asyncio
import os
import sys
import threading
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


@pytest.fixture()
def sandbox(tmp_path, monkeypatch):
    """Point the sandbox at a temp dir BEFORE tool modules read ALLOWED_ROOTS."""
    from exora_agent import config
    from exora_agent.tools import common
    monkeypatch.setattr(config, "ALLOWED_ROOTS", [tmp_path.resolve()])
    monkeypatch.setattr(common, "ALLOWED_ROOTS", [tmp_path.resolve()])
    return tmp_path


class FakeCtx:
    """Minimal stand-in for ADK ToolContext (only .state is used by our tools)."""
    def __init__(self):
        self.state = {}


def test_sandbox_blocks_outside_paths(sandbox):
    from exora_agent.tools.files import file_exists
    res = file_exists("/etc/passwd")
    assert res["status"] == "error" and "outside the allowed" in res["error"]


def test_search_rename_move_verify(sandbox):
    from exora_agent.tools.files import file_exists, move_file, rename_file, search_files
    (sandbox / "Downloads").mkdir()
    f = sandbox / "Downloads" / "Quarterly Report.txt"
    f.write_text("hello")
    found = search_files("quarterly report", str(sandbox))
    assert found["status"] == "success" and found["count"] == 1
    ren = rename_file(str(f), "report_final.txt")
    assert ren["verified"] is True
    mv = move_file(ren["new_path"], str(sandbox / "Documents" / "Archive"))
    assert mv["verified"] is True and Path(mv["new_path"]).read_text() == "hello"
    assert file_exists(mv["new_path"])["verified"] is True
    assert file_exists(str(f))["verified"] is False          # original is really gone


def test_missing_file_gives_recovery_hint(sandbox):
    from exora_agent.tools.files import search_files
    res = search_files("does-not-exist", str(sandbox))
    assert res["status"] == "error" and "hint" in res


def test_rename_never_overwrites(sandbox):
    from exora_agent.tools.files import rename_file
    a, b = sandbox / "a.txt", sandbox / "b.txt"
    a.write_text("1"); b.write_text("2")
    res = rename_file(str(a), "b.txt")
    assert res["status"] == "error" and b.read_text() == "2" and a.exists()


def test_spreadsheet_roundtrip_verified(sandbox):
    from exora_agent.tools.spreadsheet import (spreadsheet_create, spreadsheet_read,
                                               spreadsheet_verify_cell, spreadsheet_write_row)
    p = str(sandbox / "contacts.xlsx")
    assert spreadsheet_create(p, ["Name", "Email", "City"])["verified"]
    r1 = spreadsheet_write_row(p, ["Asha Rao", "asha@example.com", "Bengaluru"])
    r2 = spreadsheet_write_row(p, ["Ravi", "ravi@example.com", "42"])
    assert (r1["row"], r2["row"]) == (2, 3) and r1["verified"] and r2["verified"]
    assert spreadsheet_verify_cell(p, "B2", "asha@example.com")["verified"] is True
    assert spreadsheet_verify_cell(p, "B2", "wrong@example.com")["verified"] is False
    assert spreadsheet_read(p)["rows"][0] == ["Name", "Email", "City"]


def test_write_text_file_verified(sandbox):
    from exora_agent.tools.files import write_text_file
    res = write_text_file(str(sandbox / "notes" / "info.md"), "# Title\nbody")
    assert res["verified"] is True


def test_declare_complete_requires_verification():
    from exora_agent.tools.control import declare_task_complete
    ctx = FakeCtx()
    refused = declare_task_complete(True, "done", ["I did it"], ctx)           # no verification yet
    assert refused["status"] == "error" and "REFUSED" in refused["error"]
    ctx.state.update(verifications=1, unverified_actions=["move_file"])        # action after last verification
    assert declare_task_complete(True, "done", ["x"], ctx)["status"] == "error"
    ctx.state.update(unverified_actions=[])
    assert declare_task_complete(True, "done", [], ctx)["status"] == "error"   # evidence mandatory
    assert declare_task_complete(True, "done", ["file_exists ok"], ctx)["status"] == "success"
    assert ctx.state["task_outcome"]["success"] is True


def test_honest_failure_always_allowed():
    from exora_agent.tools.control import declare_task_complete
    ctx = FakeCtx()
    assert declare_task_complete(False, "could not find the file", [], ctx)["status"] == "success"
    assert ctx.state["task_outcome"]["success"] is False


def test_callbacks_track_verification_state():
    from types import SimpleNamespace
    from exora_agent.callbacks import after_tool
    ctx = FakeCtx()
    tool = lambda n: SimpleNamespace(name=n)
    after_tool(tool("browser_click"), {}, ctx, {"status": "success"})
    assert ctx.state["unverified_actions"] == ["browser_click"]
    after_tool(tool("browser_get_page_state"), {}, ctx, {"status": "success"})
    assert ctx.state["unverified_actions"] == [] and ctx.state["verifications"] == 1
    after_tool(tool("move_file"), {}, ctx, {"status": "success", "verified": True})
    assert ctx.state["unverified_actions"] == []                                # self-verified


def test_loop_breaker_blocks_identical_calls():
    from types import SimpleNamespace
    from exora_agent.callbacks import before_tool
    ctx = FakeCtx()
    tool = SimpleNamespace(name="browser_click")
    assert before_tool(tool, {"selector": "5"}, ctx) is None
    assert before_tool(tool, {"selector": "5"}, ctx) is None
    blocked = before_tool(tool, {"selector": "5"}, ctx)
    assert blocked and blocked["status"] == "error" and "Loop detected" in blocked["error"]


def test_approval_grant_is_single_use():
    from exora_agent.tracking import ApprovalGate
    g = ApprovalGate()
    assert g.grant_available() is False
    g.request("submit form", ["name: x"]); g.decide(True); g.grant()
    assert g.grant_available() is True
    assert g.consume_grant() is True and g.grant_available() is False


def test_request_user_approval_blocks_until_ui_decides():
    from exora_agent.tools.control import request_user_approval
    from exora_agent.tracking import APPROVAL
    APPROVAL.reset()
    ctx = FakeCtx()

    def human():
        while APPROVAL.pending is None:
            pass
        APPROVAL.decide(True)

    t = threading.Thread(target=human); t.start()
    res = asyncio.run(request_user_approval("Submit contact form", ["Name: Test"], ctx))
    t.join()
    assert res["approved"] is True and APPROVAL.grant_available() is True
    APPROVAL.reset()


def test_stop_flag_aborts_tools():
    from exora_agent.tools.files import list_directory
    from exora_agent.tracking import STOP
    STOP.set()
    try:
        assert list_directory("~")["stopped"] is True
    finally:
        STOP.clear()
