"""End-to-end ADK integration test with a SCRIPTED model (no API key, no network).

It drives the real pipeline - AgentTaskController -> ADK Runner -> callbacks -> real tools on a temp
folder - and proves: tool calling works, session state is written, verification gate refuses a premature
'success', and the tracker ends in SUCCESS. Only the LLM is replaced.
"""
import os
import sys
import tempfile
import time
from pathlib import Path

import pytest
from google.adk.models.base_llm import BaseLlm
from google.adk.models.llm_response import LlmResponse
from google.genai import types

SANDBOX = tempfile.mkdtemp(prefix="exora_it_")
os.environ["EXORA_ALLOWED_ROOTS"] = SANDBOX          # must be set before exora_agent.config is imported
os.environ.setdefault("GOOGLE_API_KEY", "dummy")
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def call(name, **args):
    return types.Part(function_call=types.FunctionCall(name=name, args=args))


class ScriptedLlm(BaseLlm):
    """Plays back a fixed list of model turns (each turn = list of Parts)."""
    script: list = []
    turn: int = 0
    fail_first: bool = False
    failed: bool = False

    async def generate_content_async(self, llm_request, stream=False):
        if self.fail_first and not self.failed:               # simulate Groq's malformed-tool-call 400
            object.__setattr__(self, "failed", True)
            raise RuntimeError('GroqException - {"error":{"code":"tool_use_failed","message":"Failed to call a function"}}')
        parts = self.script[self.turn] if self.turn < len(self.script) else [types.Part(text="done")]
        object.__setattr__(self, "turn", self.turn + 1)
        yield LlmResponse(content=types.Content(role="model", parts=parts))


def test_full_task_with_verification_gate():
    from exora_agent.agent import root_agent
    from exora_agent.runtime import AgentTaskController
    from exora_agent.tracking import TRACKER

    src = Path(SANDBOX) / "Downloads"; src.mkdir()
    (src / "Sales Report.txt").write_text("q3 numbers")
    dest = Path(SANDBOX) / "Documents" / "Archive"
    final = dest / "sales_final.txt"

    script = [
        [call("set_plan", steps=["find file", "rename", "move", "verify"])],
        [call("search_files", query="sales report", directory=str(src))],
        [call("rename_file", path=str(src / "Sales Report.txt"), new_name="sales_final.txt")],
        [call("move_file", source=str(src / "sales_final.txt"), destination_dir=str(dest))],
        # premature claim: a self-verified move happened, but evidence list is empty -> must be refused
        [call("declare_task_complete", success=True, summary="moved it", evidence=[])],
        [call("file_exists", path=str(final))],
        [call("declare_task_complete", success=True, summary="Renamed and moved the report.",
              evidence=[f"file_exists: {final}"])],
        [types.Part(text="The report was renamed and moved.")],
    ]
    root_agent.model = ScriptedLlm(model="scripted", script=script)

    ctrl = AgentTaskController()
    assert ctrl.start("Rename the sales report and move it to Documents/Archive")
    deadline = time.time() + 30
    while ctrl.running and time.time() < deadline:
        time.sleep(0.2)

    snap = TRACKER.snapshot()
    msgs = " | ".join(e.message for e in snap["entries"])
    assert snap["status"] == "success", msgs
    assert final.read_text() == "q3 numbers" and not (src / "sales_final.txt").exists()
    assert any("Evidence is required" in e.message for e in snap["entries"]), "premature success was not refused"
    assert snap["counters"]["tool_calls"] >= 6 and snap["counters"]["verifications"] >= 2
    assert snap["plan"] and snap["plan"][0]["step"] == "find file"


def test_malformed_tool_call_is_retried_automatically():
    from exora_agent.agent import root_agent
    from exora_agent.runtime import AgentTaskController
    from exora_agent.tracking import TRACKER

    f = Path(SANDBOX) / "retry_me.txt"
    script = [
        [call("write_text_file", path=str(f), content="hello")],
        [call("file_exists", path=str(f))],
        [call("declare_task_complete", success=True, summary="written", evidence=[f"file_exists {f}"])],
        [types.Part(text="done")],
    ]
    root_agent.model = ScriptedLlm(model="scripted", script=script, fail_first=True)
    ctrl = AgentTaskController()
    assert ctrl.start("Write a file")
    deadline = time.time() + 30
    while ctrl.running and time.time() < deadline:
        time.sleep(0.2)
    snap = TRACKER.snapshot()
    assert snap["status"] == "success", [e.message for e in snap["entries"]]
    assert any("malformed tool call" in e.message for e in snap["entries"])
    assert f.read_text() == "hello"
