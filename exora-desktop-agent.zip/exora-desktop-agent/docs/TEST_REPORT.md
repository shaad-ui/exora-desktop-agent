# Testing report (record what ACTUALLY happened - no simulated logs)

Environment: OS ___ / Python ___ / ADK ___ / model ___ / browser ___

| # | Task (exact instruction) | Result (pass/fail) | Steps / tool calls | Errors encountered | How the agent recovered | Evidence (screenshot / recording / file path) |
|---|--------------------------|--------------------|--------------------|--------------------|-------------------------|-----------------------------------------------|
| 1 | Download a file from a website | | | | | |
| 2 | Find, rename, move a file | | | | | |
| 3 | Enter data into a spreadsheet | | | | | |
| 4 | Fill a form, stop before submit, approve/reject | | | | | |
| 5 | Unexpected situation (missing file / popup / slow page) | | | | | |

## Failures and root causes

## Automated tests
`python -m pytest -q` -> paste output (offline tests + scripted-model ADK integration test).
