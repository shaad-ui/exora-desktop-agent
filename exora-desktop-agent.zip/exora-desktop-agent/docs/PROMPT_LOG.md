# Prompt documentation (fill in with your REAL history - the assignment asks for honesty)

**AI models / tools used**: Claude (design + code generation), Gemini `gemini-2.5-flash` (agent runtime), <add others: Cursor, Copilot...>

## 1. Prompts given to AI coding assistants
| # | Date | Assistant | Prompt (paste verbatim) | Result | What I changed afterwards |
|---|------|-----------|-------------------------|--------|---------------------------|
| 1 | | Claude | "Act as a Principal AI Engineer ... build a production-ready Exora AI Desktop Automation Agent with Google ADK ..." (full prompt) | Generated project skeleton, tools, UI | |
| 2 | | | | | |

## 2. Agent system instruction
Final version: `exora_agent/prompts.py`. Record every revision here:
| Version | Change | Why (what failed in testing) |
|---------|--------|------------------------------|
| v1 | initial | |

## 3. Tool instructions (docstrings = the tool prompts the model sees)
Location: docstrings in `exora_agent/tools/*.py`. Note any docstring you rewrote because the model misused a tool.

## 4. Debugging prompts
| Symptom | Prompt used | Fix |
|---------|-------------|-----|

## 5. Initial prompts that did not work -> what changed
